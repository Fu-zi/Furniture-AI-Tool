export const SOFAS = [
  {
    "id": "DEMO-01",
    "name": "Demo Sofa 01",
    "image": "/demo-assets/DEMO-01.svg",
    "productImage": "/demo-assets/DEMO-01.svg",
    "year": "Demo Series",
    "seriesLabel": "Demo Series",
    "structure": "直排沙发",
    "seats": "三人位",
    "structureTags": [
      "直排沙发"
    ],
    "material": "布艺",
    "hasFunction": false
  },
  {
    "id": "DEMO-02",
    "name": "Demo Sofa 02",
    "image": "/demo-assets/DEMO-02.svg",
    "productImage": "/demo-assets/DEMO-02.svg",
    "year": "Demo Series",
    "seriesLabel": "Demo Series",
    "structure": "L型沙发",
    "seats": "四人位",
    "structureTags": [
      "L型沙发"
    ],
    "material": "真皮",
    "hasFunction": false
  },
  {
    "id": "DEMO-03",
    "name": "Demo Sofa 03",
    "image": "/demo-assets/DEMO-03.svg",
    "productImage": "/demo-assets/DEMO-03.svg",
    "year": "Demo Series",
    "seriesLabel": "Demo Series",
    "structure": "功能沙发",
    "seats": "三人位",
    "structureTags": [
      "功能沙发"
    ],
    "material": "绒布",
    "hasFunction": true
  }
];

export const STRUCTURE_CATEGORIES = ['直排沙发', 'L型沙发', '功能沙发'];
export const SEAT_CATEGORIES = ['三人位', '四人位'];
export const SERIES_CATEGORIES = [{ label: 'Demo Series', year: 'Demo Series' }];
export const FABRICS = [{ id: 'leather', label: '真皮', desc: '细腻耐用' }, { id: 'linen', label: '亚麻布', desc: '自然透气' }, { id: 'velvet', label: '绒布', desc: '柔软舒适' }];
export const COLORS = [{ id: 'cream', label: '米白', hex: '#E8E0D2' }, { id: 'taupe', label: '暖咖', hex: '#A58B70' }, { id: 'green', label: '橄榄绿', hex: '#3F604D' }, { id: 'navy', label: '深蓝', hex: '#2F4568' }, { id: 'charcoal', label: '炭灰', hex: '#464646' }, { id: 'custom', label: '自选颜色', hex: 'conic-gradient(from 90deg, #e8e0d2, #a58b70, #3f604d, #2f4568, #464646, #e8e0d2)' }];
export const ANGLES = [{ id: 'auto', label: 'AI 自动' }, { id: 'front', label: '正视角' }, { id: 'left', label: '左侧视' }, { id: 'right', label: '右侧视' }];
const toCompressedDataUrl = (url, { maxSize = 1400, quality = 0.86 } = {}) => new Promise((resolve, reject) => { const image = new Image(); image.crossOrigin = 'anonymous'; image.onload = () => { const scale = Math.min(1, maxSize / Math.max(image.width, image.height)); const width = Math.max(1, Math.round(image.width * scale)); const height = Math.max(1, Math.round(image.height * scale)); const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height; const context = canvas.getContext('2d'); context.fillStyle = '#ffffff'; context.fillRect(0, 0, width, height); context.drawImage(image, 0, 0, width, height); resolve(canvas.toDataURL('image/jpeg', quality)); }; image.onerror = reject; image.src = url; });
export const mockGenerateImage = async (config) => { const { sofa, fabric, color, angle, uploadedImg } = config; const roomImage = await toCompressedDataUrl(uploadedImg, { maxSize: 1400, quality: 0.86 }); const productImage = await toCompressedDataUrl(sofa.productImage || sofa.image, { maxSize: 1400, quality: 0.9 }); const fabricLabel = FABRICS.find(item => item.id === fabric)?.label || '默认面料'; const colorLabel = color?.startsWith('custom:') ? color.replace('custom:', '') : COLORS.find(item => item.id === color)?.label || '默认颜色'; const angleLabel = ANGLES.find(item => item.id === angle)?.label || 'AI 自动'; const prompt = `Replace the sofa in the uploaded living-room photo with the selected demo sofa product. Preserve room layout, camera angle, lighting, scale, and perspective. Product: ${sofa.name}; fabric: ${fabricLabel}; color: ${colorLabel}; angle preference: ${angleLabel}. Photorealistic interior visualization, no text, no logo, no watermark.`; const response = await fetch('/api/generate-image', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ prompt, imageUrls: [roomImage, productImage], metadata: { sofaId: sofa.id, sofaName: sofa.name, originalImage: roomImage, configSnapshot: { sofa, fabric, color, angle } } }) }); if (!response.ok) { let errMsg = 'AI generation request failed'; try { const errJson = await response.json(); errMsg = errJson.error || errMsg; } catch {} throw new Error(`API error: ${errMsg}`); } try { return await response.json(); } catch { throw new Error('Invalid JSON returned by API.'); } };
