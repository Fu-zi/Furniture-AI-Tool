import { useState, useMemo, useRef, useEffect } from 'react';
import UploadZone from './components/UploadZone';
import SofaSelector from './components/SofaSelector';
import LoadingOverlay from './components/LoadingOverlay';
import ResultDisplay from './components/ResultDisplay';
import { mockGenerateImage, SEAT_CATEGORIES, SERIES_CATEGORIES, SOFAS, STRUCTURE_CATEGORIES } from './data';
import heroImage from './assets/hero-sofa.svg';
import brandIcon from './assets/brand-icon.svg';
import './index.css';
import './App.css';

const INITIAL_CONFIG = {
  sofa: null,
  fabric: null,
  color: null,
  angle: 'auto',
};

const createHistoryItem = ({ status, config, uploadedImg, imageUrl, clientTaskId, providerTaskId, message }) => ({
  id: clientTaskId || `local-${Date.now()}`,
  status,
  imageUrl: imageUrl || null,
  originalImage: uploadedImg,
  sofaName: config.sofa?.name || '未命名沙发',
  configSnapshot: config,
  clientTaskId,
  providerTaskId,
  message,
  createdAt: new Date().toISOString(),
});

const DEFAULT_CATALOG = {
  sofas: SOFAS,
  structureCategories: STRUCTURE_CATEGORIES,
  seatCategories: SEAT_CATEGORIES,
  seriesCategories: SERIES_CATEGORIES,
};

const mergeCatalog = (payload) => {
  const productMap = new Map(SOFAS.map(sofa => [sofa.id, sofa]));
  (payload?.products || []).forEach(product => {
    if (product?.id) productMap.set(product.id, product);
  });

  const unique = (items) => [...new Set(items.filter(Boolean))];
  const seriesMap = new Map(SERIES_CATEGORIES.map(series => [series.label, series]));
  (payload?.seriesCategories || []).forEach(series => {
    if (series?.label) seriesMap.set(series.label, series);
  });

  return {
    sofas: [...productMap.values()],
    structureCategories: unique([
      ...STRUCTURE_CATEGORIES,
      ...(payload?.structureCategories || []),
    ]),
    seatCategories: unique([
      ...SEAT_CATEGORIES,
      ...(payload?.seatCategories || []),
    ]),
    seriesCategories: [...seriesMap.values()],
  };
};

function LoginScreen({ onLogin, loading }) {
  const [username, setUsername] = useState('test');
  const [password, setPassword] = useState('msm2026');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await onLogin({ username, password });
    } catch (loginError) {
      setError(loginError.message || '登录失败，请检查账户名和密码');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="login-page" aria-label="登录 Demo Sofa AI AI 沙发搭配演示">
      <section className="login-card">
        <div className="login-brand">
          <span className="brand-icon-wrap" aria-hidden="true">
            <img className="brand-icon" src={brandIcon} alt="" />
          </span>
          <div>
            <strong>Demo Sofa AI</strong>
            <span>AI 沙发搭配演示</span>
          </div>
        </div>
        <div className="login-copy">
          <p className="section-eyebrow">演示门店演示登录</p>
          <h1>登录后开始生成 AI 沙发搭配效果</h1>
          <p>登录后每日可生成 10 张 AI 沙发搭配效果图</p>
        </div>
        <form className="login-form" onSubmit={handleSubmit}>
          <label>
            账户名
            <input
              value={username}
              onChange={event => setUsername(event.target.value)}
              autoComplete="username"
              placeholder="请输入账户名"
              disabled={loading || submitting}
              required
            />
          </label>
          <label>
            密码
            <input
              value={password}
              onChange={event => setPassword(event.target.value)}
              autoComplete="current-password"
              placeholder="请输入密码"
              type="password"
              disabled={loading || submitting}
              required
            />
          </label>
          {error && <p className="login-error" role="alert">{error}</p>}
          <button className="btn-primary" type="submit" disabled={loading || submitting}>
            {loading ? '正在检查登录状态...' : submitting ? '登录中...' : '登录进入'}
          </button>
        </form>
        <div className="login-footnote">
          <span>Demo 账户：test</span>
          <span>后续可平滑替换为正式登录方式</span>
        </div>
      </section>
    </main>
  );
}

export default function App() {
  const [auth, setAuth] = useState({ loading: true, user: null, quota: null });
  const [uploadedImg, setUploadedImg] = useState(null);
  const [config, setConfig] = useState(INITIAL_CONFIG);
  const [generating, setGenerating] = useState(false);
  const [resultImg, setResultImg] = useState(null);
  const [resultConfig, setResultConfig] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [loadingKey, setLoadingKey] = useState(0);
  const [history, setHistory] = useState([]);
  const [activePanel, setActivePanel] = useState('upload');
  const [catalog, setCatalog] = useState(DEFAULT_CATALOG);
  const generationRunRef = useRef(0);

  const canGenerate = uploadedImg && config.sofa;
  const quotaExhausted = auth.quota && auth.quota.remaining <= 0;
  const hasProcessingTask = history.some(item => item.status === 'processing');

  const moduleTabs = useMemo(() => ([
    {
      id: 'upload',
      index: '01',
      label: '上传照片',
      summary: uploadedImg ? '已上传客厅照' : '先上传客厅照',
      done: Boolean(uploadedImg),
    },
    {
      id: 'select',
      index: '02',
      label: '选择沙发',
      summary: config.sofa ? config.sofa.name : '上传后可选款',
      done: Boolean(config.sofa),
      locked: !uploadedImg,
    },
    {
      id: 'result',
      index: '03',
      label: '查看结果',
      summary: resultImg ? '效果图已生成' : '生成后查看',
      done: Boolean(resultImg),
      locked: !resultImg,
    },
    {
      id: 'history',
      index: '04',
      label: '历史记录',
      summary: history.length ? `${history.length} 条记录` : '暂无记录',
      done: history.length > 0,
    },
  ]), [uploadedImg, config.sofa, resultImg, history.length]);

  const loadUserHistory = async () => {
    const response = await fetch('/api/history', { credentials: 'include' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || '读取历史记录失败');
    setHistory(data.tasks || []);
    if (data.quota) {
      setAuth(current => ({ ...current, quota: data.quota }));
    }
    return data;
  };

  const loadProductCatalog = async () => {
    const response = await fetch('/api/products', { credentials: 'include' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || '读取产品数据失败');
    setCatalog(mergeCatalog(data));
    return data;
  };

  useEffect(() => {
    let cancelled = false;

    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me', { credentials: 'include' });
        const data = await response.json();
        if (cancelled) return;
        if (data.user) {
          setAuth({ loading: false, user: data.user, quota: data.quota });
          loadProductCatalog().catch(() => {});
          const historyResponse = await fetch('/api/history', { credentials: 'include' });
          const historyData = await historyResponse.json();
          if (!cancelled && historyResponse.ok) {
            setHistory(historyData.tasks || []);
            if (historyData.quota) setAuth(current => ({ ...current, quota: historyData.quota }));
          }
        } else {
          setAuth({ loading: false, user: null, quota: null });
        }
      } catch {
        if (!cancelled) setAuth({ loading: false, user: null, quota: null });
      }
    };

    checkAuth();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!feedback) return undefined;
    const timer = window.setTimeout(() => setFeedback(''), 5000);
    return () => window.clearTimeout(timer);
  }, [feedback]);

  const handleLogin = async ({ username, password }) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || '登录失败');
    setAuth({ loading: false, user: data.user, quota: data.quota });
    await loadProductCatalog();
    await loadUserHistory();
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
    setAuth({ loading: false, user: null, quota: null });
    setHistory([]);
    setCatalog(DEFAULT_CATALOG);
    resetAll();
  };

  const handlePanelSelect = (panelId) => {
    if (panelId === 'select' && !uploadedImg) {
      setFeedback('请先上传客厅照片，再选择沙发方案。');
      setActivePanel('upload');
      return;
    }
    if (panelId === 'result' && !resultImg) {
      setFeedback('还没有生成效果图。生成完成后会自动切换到这里。');
      return;
    }
    setActivePanel(panelId);
  };

  const saveHistory = (nextHistory) => {
    const trimmed = nextHistory.slice(0, 30);
    setHistory(trimmed);
  };

  const addHistoryItem = (item) => {
    saveHistory([item, ...history.filter(existing => existing.id !== item.id)]);
  };

  const handleImageChange = (image) => {
    setUploadedImg(image);
    setResultImg(null);
    setResultConfig(null);

    if (image) {
      setActivePanel('select');
      return;
    }

    setConfig(INITIAL_CONFIG);
    setActivePanel('upload');
  };

  const startGeneration = async () => {
    if (hasProcessingTask) {
      setFeedback('已有生成任务正在处理中，请等待完成后再提交，避免重复扣费。');
      return;
    }
    if (!canGenerate) {
      setFeedback('请先上传客厅照片并选择沙发款式');
      return;
    }
    if (quotaExhausted) {
      setFeedback('今日 AI 搭配额度已用完，请明天再试');
      return;
    }
    const runId = generationRunRef.current + 1;
    generationRunRef.current = runId;
    setLoadingKey(runId);
    setGenerating(true);
    try {
      const taskResult = await mockGenerateImage({ ...config, uploadedImg });
      if (generationRunRef.current !== runId) return;
      if (taskResult.quota) {
        setAuth(current => ({ ...current, quota: taskResult.quota }));
      }

      const item = createHistoryItem({
        status: taskResult.status || (taskResult.imageUrl ? 'completed' : 'processing'),
        config,
        uploadedImg,
        imageUrl: taskResult.imageUrl,
        clientTaskId: taskResult.clientTaskId,
        providerTaskId: taskResult.providerTaskId,
        message: taskResult.message,
      });
      addHistoryItem(item);
      loadUserHistory().catch(() => {});

      if (taskResult.imageUrl) {
        setResultImg(taskResult.imageUrl);
        setResultConfig(config);
        setActivePanel('result');
        setFeedback('生成完成，已切换到效果图。');
      } else {
        setResultImg(null);
        setResultConfig(null);
        setActivePanel('history');
        setFeedback(taskResult.message || '任务已提交，生成时间可能较长，请在历史任务中查看状态。');
      }
    } catch (e) {
      if (generationRunRef.current !== runId) return;
      setFeedback(e.message || '生成失败，请稍后再试');
    } finally {
      if (generationRunRef.current === runId) setGenerating(false);
    }
  };

  const resetAll = () => {
    setUploadedImg(null);
    setConfig(INITIAL_CONFIG);
    setResultImg(null);
    setResultConfig(null);
    setActivePanel('upload');
  };

  const updateConfig = (nextConfig) => {
    setConfig(nextConfig);
    setResultImg(null);
    setResultConfig(null);
    setActivePanel('select');
  };

  const cancelGeneration = () => {
    generationRunRef.current += 1;
    setLoadingKey(generationRunRef.current);
    setGenerating(false);
    setFeedback('已取消本次生成');
  };

  const clearProcessingLock = (id) => {
    fetch(`/api/history/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({
        status: 'needs-review',
        message: '已标记为待查看，请到 API 后台确认是否成功。',
      }),
    })
      .then(response => response.json())
      .then(data => {
        setHistory(data.tasks || history.map(item => (
          item.id === id
            ? { ...item, status: 'needs-review', message: '已标记为待查看，请到 API 后台确认是否成功。' }
            : item
        )));
      })
      .catch(() => setFeedback('更新历史记录失败'));
  };

  const refreshHistoryTask = async (item) => {
    if (!item.providerTaskId) {
      setFeedback('这条记录没有供应商 taskId，无法刷新。');
      return;
    }

    setFeedback('正在查询 AI 生成任务状态...');
    try {
      const response = await fetch('/api/query-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ taskId: item.providerTaskId }),
      });
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || '查询任务失败');
      }

      const nextStatus = result.imageUrl ? 'completed' : (
        result.status === 'success' ? 'processing' : result.status || item.status
      );
      const updatedItem = {
        ...item,
        status: nextStatus,
        imageUrl: result.imageUrl || item.imageUrl,
        message: result.message || item.message,
      };

      saveHistory(history.map(existing => (
        existing.id === item.id ? updatedItem : existing
      )));

      if (result.imageUrl) {
        setUploadedImg(updatedItem.originalImage);
        setResultImg(result.imageUrl);
        setResultConfig(updatedItem.configSnapshot || config);
        setActivePanel('result');
        setFeedback('任务已完成，结果图已显示。');
      } else {
        setFeedback(result.message || '任务还在处理中，请稍后再刷新。');
      }
      loadUserHistory().catch(() => {});
    } catch (error) {
      setFeedback(error.message || '查询任务失败');
    }
  };

  const removeHistoryItem = (id) => {
    fetch(`/api/history/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      credentials: 'include',
    })
      .then(response => response.json())
      .then(data => setHistory(data.tasks || history.filter(item => item.id !== id)))
      .catch(() => setFeedback('删除历史记录失败'));
  };

  const openHistoryResult = (item) => {
    if (!item.imageUrl) {
      setFeedback('当前未成功生成图片，请重新再试，或联系工作人员。');
      return;
    }
    setUploadedImg(item.originalImage);
    setResultImg(item.imageUrl);
    setResultConfig(item.configSnapshot || config);
    setActivePanel('result');
  };

  const attachResultUrl = (item) => {
    const imageUrl = window.prompt('请联系工作人员');
    if (!imageUrl) return;
    const normalizedUrl = imageUrl.trim();
    if (!/^https?:\/\//.test(normalizedUrl) && !normalizedUrl.startsWith('data:image/')) {
      setFeedback('请输入有效的图片 URL');
      return;
    }

    fetch(`/api/history/${encodeURIComponent(item.id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({
        status: 'completed',
        imageUrl: normalizedUrl,
        message: '已手动回填生成结果。',
      }),
    })
      .then(response => response.json())
      .then(data => {
        const completedItem = data.task || {
          ...item,
          status: 'completed',
          imageUrl: normalizedUrl,
          message: '已手动回填生成结果。',
        };
        setHistory(data.tasks || history.map(existing => (
          existing.id === item.id ? completedItem : existing
        )));
        setUploadedImg(completedItem.originalImage);
        setResultImg(normalizedUrl);
        setResultConfig(completedItem.configSnapshot || config);
        setActivePanel('result');
      })
      .catch(() => setFeedback('回填图片链接失败'));
  };

  if (auth.loading || !auth.user) {
    return <LoginScreen onLogin={handleLogin} loading={auth.loading} />;
  }

  return (
    <div className="app-container" id="app-container">
      <header className="app-header hero-panel">
        <div className="brand-row">
          <span className="brand-lockup">
            <span className="brand-icon-wrap" aria-hidden="true">
              <img className="brand-icon" src={brandIcon} alt="" />
            </span>
            <span className="brand-copy">
              <span className="brand-title">Demo Sofa AI</span>
              <span className="brand-subtitle">AI 沙发搭配演示</span>
            </span>
          </span>
          <span className="brand-mode">
            今日剩余 {auth.quota?.remaining ?? 10} 张
          </span>
          <button className="logout-button" type="button" onClick={handleLogout}>
            退出
          </button>
        </div>
        <div className="hero-copy">
          <p className="app-kicker">顾客实景搭配</p>
          <h1 className="app-title">上传客厅照，现场看沙发上家效果</h1>
          <p className="app-subtitle">为您快速确认尺寸、风格和空间氛围，提前看见理想客厅效果。</p>
        </div>
        <div className="hero-preview" aria-label="演示品牌沙发搭配示例">
          <img src={heroImage} alt="演示品牌沙发搭配效果示例" />
          <div className="preview-badge">AI 效果预览</div>
          <div className="preview-note">
            <span>30-60 秒生成</span>
            <span>高清保存</span>
            <span>顾客分享</span>
          </div>
        </div>
        <div className="trust-strip" aria-label="核心优势">
          <span>
            <strong>实景上传</strong>
            <small>保留您客厅的真实空间比例与光线</small>
          </span>
          <span>
            <strong>演示品牌选款</strong>
            <small>快速匹配热销型号与空间风格</small>
          </span>
          <span>
            <strong>到店确认</strong>
            <small>讲解尺寸、面料和现货方案</small>
          </span>
        </div>
      </header>

      <nav className="module-switcher" aria-label="功能模块切换">
        {moduleTabs.map(tab => (
          <button
            type="button"
            className={`module-tab ${activePanel === tab.id ? 'active' : ''} ${tab.done ? 'done' : ''} ${tab.locked ? 'locked' : ''}`}
            key={tab.id}
            onClick={() => handlePanelSelect(tab.id)}
            aria-current={activePanel === tab.id ? 'page' : undefined}
          >
            <span className="module-index">{tab.index}</span>
            <span className="module-copy">
              <strong>{tab.label}</strong>
              <small>{tab.summary}</small>
            </span>
          </button>
        ))}
      </nav>

      {activePanel === 'upload' && (
        <section className="section upload-section" aria-labelledby="upload-title">
          <div className="section-heading">
            <p className="section-eyebrow">Step 01</p>
            <h2 id="upload-title">上传顾客客厅实景</h2>
            <p>建议使用横向、光线充足的客厅照片，沙发墙和地面尽量完整。</p>
          </div>
          <UploadZone image={uploadedImg} onImageChange={handleImageChange} onError={setFeedback} />
        </section>
      )}

      {activePanel === 'select' && uploadedImg && (
        <section className="section configurator-section" aria-labelledby="selector-title">
          <div className="section-heading">
            <p className="section-eyebrow">Step 02</p>
            <h2 id="selector-title">选择演示品牌沙发方案</h2>
            <p>优先推荐热销型号，方便演示门店快速讲解风格、材质和适配场景。</p>
          </div>
          <SofaSelector config={config} onChange={updateConfig} catalog={catalog} />
          <div className="generate-actions">
            <button
              id="generate-btn"
              className="btn-primary"
              disabled={!canGenerate || generating || hasProcessingTask}
              onClick={startGeneration}
            >
              {hasProcessingTask ? '已有任务处理中' : generating ? '提交中...' : '提交生成任务'}
            </button>
            <button
              id="reset-all-btn"
              className="btn-secondary"
              onClick={resetAll}
            >
              重新开始
            </button>
          </div>
        </section>
      )}

      {activePanel === 'result' && resultImg && (
        <section className="section result-section" aria-labelledby="result-title">
          <ResultDisplay
            originalImage={uploadedImg}
            resultImage={resultImg}
            config={resultConfig || config}
            onRegenerate={startGeneration}
            onReset={resetAll}
            onFeedback={setFeedback}
          />
        </section>
      )}

      {activePanel === 'history' && (
        <section className="section history-section" aria-labelledby="history-title">
          <div className="section-heading">
            <p className="section-eyebrow">History</p>
            <h2 id="history-title">历史效果图与生成任务</h2>
            <p>AI 图片生成可能需要 30-60 秒完成。请耐心等待。</p>
          </div>
          {history.length === 0 ? (
            <div className="history-empty">
              <strong>暂无历史记录</strong>
              <p>提交生成任务后，生成中、已完成和手动回填的效果图都会集中保存在这里。</p>
              <button
                type="button"
                className="btn-secondary"
                onClick={() => handlePanelSelect(uploadedImg ? 'select' : 'upload')}
              >
                去生成第一张
              </button>
            </div>
          ) : (
            <div className="history-list">
              {history.map(item => (
                <article className={`history-card status-${item.status}`} key={item.id}>
                  <div className="history-thumb">
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={`${item.sofaName} 历史效果图`} />
                    ) : (
                      <div className="history-pending">生成中</div>
                    )}
                  </div>
                  <div className="history-content">
                    <div className="history-title-row">
                      <strong>{item.sofaName}</strong>
                      <span>{item.status === 'completed' ? '已完成' : item.status === 'processing' ? '处理中' : '待查看'}</span>
                    </div>
                    <p>{item.message || '任务已记录'}</p>
                    <small>
                      {new Date(item.createdAt).toLocaleString()} · {item.providerTaskId || item.clientTaskId || '本地任务'}
                    </small>
                    <div className="history-actions">
                      <button className="btn-secondary" onClick={() => openHistoryResult(item)}>
                        查看效果
                      </button>
                      {item.status === 'processing' && (
                        <button className="btn-secondary" onClick={() => clearProcessingLock(item.id)}>
                          我已后台查看
                        </button>
                      )}
                      {item.providerTaskId && !item.imageUrl && (
                        <button className="btn-secondary" onClick={() => refreshHistoryTask(item)}>
                          刷新状态
                        </button>
                      )}
                      {!item.imageUrl && (
                        <button className="btn-secondary" onClick={() => attachResultUrl(item)}>
                          粘贴结果图
                        </button>
                      )}
                      <button className="history-delete" onClick={() => removeHistoryItem(item.id)}>
                        移除
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      {activePanel === 'select' && uploadedImg && !resultImg && (
        <div className="mobile-generate-bar" role="region" aria-label="生成操作栏">
          <div>
            <strong>{config.sofa ? config.sofa.name : '请选择沙发型号'}</strong>
            <span>{hasProcessingTask ? '已有任务处理中' : canGenerate ? '已选沙发，可生成' : '上传照片并选择沙发'}</span>
          </div>
          <button className="btn-primary" disabled={!canGenerate || generating || hasProcessingTask} onClick={startGeneration}>
            {hasProcessingTask ? '等待中' : '提交'}
          </button>
        </div>
      )}

      {feedback && (
        <div className="toast" role="status" aria-live="polite" key={feedback}>
          <span>{feedback}</span>
        </div>
      )}

      <footer className="site-credit" aria-label="技术支持">
        技术支持 | Open Source Demo
      </footer>

      {/* Loading overlay */}
      <LoadingOverlay key={loadingKey} visible={generating} onCancel={cancelGeneration} />
    </div>
  );
}
