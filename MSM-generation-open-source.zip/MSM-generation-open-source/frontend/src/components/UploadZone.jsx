import { useState, useRef, useCallback } from 'react';
import './UploadZone.css';

export default function UploadZone({ image, onImageChange, onError }) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef(null);

  const handleFile = useCallback((file) => {
    if (!file) return;
    const allowed = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(file.type)) {
      onError?.('暂不支持该图片格式，请上传 JPG / PNG / WebP');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      onError?.('图片不能超过 10MB，请压缩后重新上传');
      return;
    }
    const url = URL.createObjectURL(file);
    onImageChange(url);
  }, [onImageChange, onError]);

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  return (
    <div
      id="upload-zone"
      className={`upload-zone ${dragging ? 'dragging' : ''} ${image ? 'has-image' : ''}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
      onClick={() => !image && inputRef.current?.click()}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        style={{ display: 'none' }}
        onChange={(e) => handleFile(e.target.files[0])}
      />

      {image ? (
        <div className="upload-preview">
          <img src={image} alt="已上传的客厅照片" />
          <div className="upload-overlay">
            <button
              id="change-photo-btn"
              className="change-photo-btn"
              onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}
            >
              更换照片
            </button>
            <button
              id="remove-photo-btn"
              className="remove-photo-btn"
              onClick={(e) => { e.stopPropagation(); onImageChange(null); }}
            >
              ✕
            </button>
          </div>
        </div>
      ) : (
        <div className="upload-placeholder">
          <div className="upload-icon">
            <svg viewBox="0 0 48 48" fill="none">
              <circle cx="24" cy="24" r="23" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 3"/>
              <path d="M24 14v14m0-14l-5 5m5-5l5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M14 34h20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4"/>
            </svg>
          </div>
          <p className="upload-label">上传客厅实景照片</p>
          <p className="upload-hint">支持 JPG / PNG / WebP，最大 10MB</p>
          <div className="upload-tips" aria-label="拍摄建议">
            <span>横向构图</span>
            <span>光线充足</span>
            <span>沙发墙完整</span>
          </div>
        </div>
      )}
    </div>
  );
}
