import { useState, useMemo } from 'react';
import {
  SOFAS as DEFAULT_SOFAS,
  STRUCTURE_CATEGORIES as DEFAULT_STRUCTURE_CATEGORIES,
  SEAT_CATEGORIES as DEFAULT_SEAT_CATEGORIES,
  SERIES_CATEGORIES as DEFAULT_SERIES_CATEGORIES,
  FABRICS,
  COLORS,
  ANGLES,
} from '../data';
import './SofaSelector.css';

const HOT_PICK_META = {
  'DEMO-01': { tag: 'Demo 推荐', reason: '适合演示场景' },
  'DEMO-02': { tag: '空间适配', reason: '适合现代客厅' },
  'DEMO-03': { tag: '功能演示', reason: '便于展示交互' },
      };

export default function SofaSelector({ config, onChange, catalog }) {
  const [activeTab, setActiveTab] = useState('browse'); // 'browse' | 'search'
  const [structureFilter, setStructureFilter] = useState('全部');
  const [seatFilter, setSeatFilter] = useState('全部');
  const [seriesFilter, setSeriesFilter] = useState('全部');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPersonalisation, setShowPersonalisation] = useState(false);
  const [customColor, setCustomColor] = useState('');
  const sofas = catalog?.sofas?.length ? catalog.sofas : DEFAULT_SOFAS;
  const structureCategories = catalog?.structureCategories?.length ? catalog.structureCategories : DEFAULT_STRUCTURE_CATEGORIES;
  const seatCategories = catalog?.seatCategories?.length ? catalog.seatCategories : DEFAULT_SEAT_CATEGORIES;
  const seriesCategories = catalog?.seriesCategories?.length ? catalog.seriesCategories : DEFAULT_SERIES_CATEGORIES;

  const filteredSofas = useMemo(() => {
    return sofas.filter(s => {
      const matchStruct = structureFilter === '全部' || (s.structureTags || [s.structure]).includes(structureFilter);
      const matchSeat   = seatFilter === '全部'      || s.seats === seatFilter;
      const selectedSeries = seriesCategories.find(series => series.label === seriesFilter);
      const matchSeries = seriesFilter === '全部'
        || s.year === selectedSeries?.year
        || s.seriesLabel === selectedSeries?.label;
      const matchSearch = s.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchStruct && matchSeat && matchSeries && matchSearch;
    });
  }, [sofas, structureFilter, seatFilter, seriesFilter, searchQuery, seriesCategories]);

  const hotPicks = useMemo(() => {
    return Object.keys(HOT_PICK_META)
      .map(id => sofas.find(sofa => sofa.id === id))
      .filter(Boolean);
  }, [sofas]);

  const selectSofa = (sofa) => onChange({
    ...config,
    sofa,
    angle: config.angle || 'auto',
  });

  const applyCustomColor = () => {
    const trimmed = customColor.trim();
    if (!trimmed) return;
    onChange({ ...config, color: `custom:${trimmed}` });
  };

  const colorName = config.color?.startsWith('custom:')
    ? config.color.replace('custom:', '')
    : COLORS.find(c => c.id === config.color)?.label;

  return (
    <div className="sofa-selector" id="sofa-selector">

      {/* ── Tab Header ── */}
      <div className="selector-tabs">
        <button
          id="tab-browse"
          className={`selector-tab ${activeTab === 'browse' ? 'active' : ''}`}
          onClick={() => setActiveTab('browse')}
        >导购推荐</button>
        <button
          id="tab-search"
          className={`selector-tab ${activeTab === 'search' ? 'active' : ''}`}
          onClick={() => setActiveTab('search')}
        >指定型号</button>
      </div>

      {activeTab === 'browse' && (
        <div className="hot-picks" aria-label="热销沙发推荐">
          {hotPicks.map(sofa => (
            <button
              key={sofa.id}
              className={`hot-pick-card ${config.sofa?.id === sofa.id ? 'selected' : ''}`}
              onClick={() => selectSofa(sofa)}
              aria-pressed={config.sofa?.id === sofa.id}
            >
              <img src={sofa.image} alt={sofa.name} loading="lazy" />
              <span className="hot-pick-badge">{HOT_PICK_META[sofa.id].tag}</span>
              <span className="hot-pick-name">{sofa.id}</span>
              <span className="hot-pick-reason">{HOT_PICK_META[sofa.id].reason}</span>
            </button>
          ))}
        </div>
      )}

      {/* ── Filters ── */}
      {activeTab === 'browse' && (
        <div className="filter-group">
          <div className="filter-summary">
            <span>全部型号</span>
            <strong>{filteredSofas.length} 款可选</strong>
          </div>
          <div className="filter-row">
            <span className="filter-label">结构</span>
            <div className="filter-chips">
              {['全部', ...structureCategories].map(c => (
                <button
                  key={c}
                  id={`filter-struct-${c}`}
                  className={`chip ${structureFilter === c ? 'active' : ''}`}
                  onClick={() => setStructureFilter(c)}
                  aria-pressed={structureFilter === c}
                >{c}</button>
              ))}
            </div>
          </div>
          <div className="filter-row">
            <span className="filter-label">座位</span>
            <div className="filter-chips">
              {['全部', ...seatCategories].map(c => (
                <button
                  key={c}
                  id={`filter-seat-${c}`}
                  className={`chip ${seatFilter === c ? 'active' : ''}`}
                  onClick={() => setSeatFilter(c)}
                  aria-pressed={seatFilter === c}
                >{c}</button>
              ))}
            </div>
          </div>
          <div className="filter-row">
            <span className="filter-label">系列</span>
            <div className="filter-chips">
              {['全部', ...seriesCategories.map(series => series.label)].map(c => (
                <button
                  key={c}
                  id={`filter-series-${c}`}
                  className={`chip ${seriesFilter === c ? 'active' : ''}`}
                  onClick={() => setSeriesFilter(c)}
                  aria-pressed={seriesFilter === c}
                >{c}</button>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'search' && (
        <div className="search-bar-wrap">
          <input
            id="sofa-search-input"
            className="search-input"
            type="text"
            placeholder="输入型号，如 DEMO-01..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
      )}

      {/* ── Sofa Grid ── */}
      <div className="sofa-grid">
        {filteredSofas.length === 0 && (
          <div className="empty-hint">
            <strong>未找到匹配的型号</strong>
            <span>请调整结构、座位或系列筛选后重新选择。</span>
          </div>
        )}
        {filteredSofas.map(sofa => (
          <button
            key={sofa.id}
            id={`sofa-card-${sofa.id}`}
            className={`sofa-card ${config.sofa?.id === sofa.id ? 'selected' : ''}`}
            onClick={() => selectSofa(sofa)}
            aria-pressed={config.sofa?.id === sofa.id}
          >
            <div className="sofa-card-img-wrap">
              <img src={sofa.image} alt={sofa.name} loading="lazy" />
              {config.sofa?.id === sofa.id && (
                <div className="sofa-card-check">选中</div>
              )}
              {HOT_PICK_META[sofa.id] && (
                <span className="sofa-card-badge">{HOT_PICK_META[sofa.id].tag}</span>
              )}
            </div>
            <div className="sofa-card-info">
              <span className="sofa-card-id">{sofa.id}</span>
              <span className="sofa-card-tag">{sofa.structure} · {sofa.seats}</span>
              <span className="sofa-card-material">{sofa.material}{sofa.hasFunction ? ' · 功能款' : ''}</span>
            </div>
          </button>
        ))}
      </div>

      {/* ── Personalisation ── */}
      <div className="personalisation" id="personalisation">
        <button
          className="personalisation-toggle"
          type="button"
          onClick={() => setShowPersonalisation(value => !value)}
          aria-expanded={showPersonalisation}
        >
          <span>
            个性化定制
            <em>未选择时，默认保留参考图中的原始材质与颜色</em>
          </span>
          <strong>{showPersonalisation ? '收起' : '展开'}</strong>
        </button>

        {showPersonalisation && (
          <div className="personalisation-panel">
            {/* Fabric */}
            <div className="option-group">
              <span className="option-label">面料</span>
              <div className="option-chips">
                {FABRICS.map(f => (
                  <button
                    key={f.id}
                    id={`fabric-${f.id}`}
                    className={`chip ${config.fabric === f.id ? 'active' : ''}`}
                    onClick={() => onChange({ ...config, fabric: f.id })}
                    aria-pressed={config.fabric === f.id}
                  >
                    {f.label}
                    <span className="chip-desc">{f.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div className="option-group">
              <span className="option-label">颜色</span>
              <div className="color-picker-wrap">
                <div className="color-swatches">
                  {COLORS.map(c => (
                    <button
                      key={c.id}
                      id={`color-${c.id}`}
                      title={c.label}
                      aria-label={`选择颜色 ${c.label}`}
                      className={`swatch ${config.color === c.id ? 'selected' : ''}`}
                      style={{ background: c.hex }}
                      onClick={() => onChange({ ...config, color: c.id })}
                      aria-pressed={config.color === c.id}
                    />
                  ))}
                  <button
                    className={`custom-color-trigger ${config.color?.startsWith('custom:') ? 'selected' : ''}`}
                    type="button"
                    onClick={() => {
                      if (!customColor.trim()) setCustomColor(colorName || '');
                    }}
                  >
                    自定义
                  </button>
                </div>
                <div className="custom-color-row">
                  <input
                    value={customColor}
                    onChange={(event) => setCustomColor(event.target.value)}
                    placeholder="如：奶油白、橄榄绿、任意颜色"
                    aria-label="自定义沙发颜色"
                  />
                  <button type="button" onClick={applyCustomColor}>应用</button>
                </div>
              </div>
              {colorName && (
                <span className="color-name">
                  {colorName}
                </span>
              )}
            </div>

            {/* Angle */}
            <div className="option-group">
              <span className="option-label">视角</span>
              <div className="option-chips">
                {ANGLES.map(a => (
                  <button
                    key={a.id}
                    id={`angle-${a.id}`}
                    className={`chip ${config.angle === a.id ? 'active' : ''}`}
                    onClick={() => onChange({ ...config, angle: a.id })}
                    aria-pressed={config.angle === a.id}
                  >{a.label}</button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
