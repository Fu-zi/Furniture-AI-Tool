import { useState, useRef, useCallback } from 'react';
import { FABRICS, COLORS } from '../data';
import './ResultDisplay.css';

export default function ResultDisplay({ originalImage, resultImage, config, onRegenerate, onReset, onFeedback }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [dragging, setDragging] = useState(false);
  const containerRef = useRef(null);
  const [saved, setSaved] = useState(false);
  const [leadOpen, setLeadOpen] = useState(false);
  const sofaName = config.sofa?.name || '';
  const fabricLabel = FABRICS.find(item => item.id === config.fabric)?.label || '参考图默认面料';
  const colorLabel = config.color?.startsWith('custom:')
    ? config.color.replace('custom:', '')
    : COLORS.find(item => item.id === config.color)?.label || '参考图默认颜色';

  const updateSlider = useCallback((clientX) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pct = Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pct);
  }, []);

  const onMouseMove = (e) => { if (dragging) updateSlider(e.clientX); };
  const onTouchMove = (e) => updateSlider(e.touches[0].clientX);

  const handleSave = async () => {
    try {
      onFeedback?.('正在准备下载高清效果图...');
      const filename = `DEMO-${sofaName || '顾客'}-搭配效果图.jpg`;
      const response = await fetch(`/api/download-image?url=${encodeURIComponent(resultImage)}&filename=${encodeURIComponent(filename)}`, {
        credentials: 'include',
      });

      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.error || '下载失败');
      }

      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objectUrl);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      onFeedback?.('高清效果图已开始下载。');
    } catch (error) {
      onFeedback?.(error.message || '保存失败，请长按图片另存为');
    }
  };

  const handlePoster = async () => {
    try {
      const poster = document.createElement('canvas');
      const width = 1080;
      const height = 1600;
      poster.width = width;
      poster.height = height;
      const ctx = poster.getContext('2d');

      ctx.fillStyle = '#FFFCF7';
      ctx.fillRect(0, 0, width, height);

      ctx.fillStyle = '#211E1B';
      ctx.font = '700 56px "Noto Serif SC", serif';
      ctx.fillText('Demo Sofa AI', 72, 112);
      ctx.fillStyle = '#7A5A2E';
      ctx.font = '700 30px "Inter", sans-serif';
      ctx.fillText('AI 沙发搭配效果', 72, 164);

      const image = new Image();
      image.crossOrigin = 'anonymous';
      image.src = resultImage;

      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = reject;
      });

      const frameX = 72;
      const frameY = 220;
      const frameW = width - 144;
      const frameH = 980;
      const imageRatio = image.width / image.height;
      const frameRatio = frameW / frameH;
      const drawW = imageRatio > frameRatio ? frameH * imageRatio : frameW;
      const drawH = imageRatio > frameRatio ? frameH : frameW / imageRatio;
      const drawX = frameX + (frameW - drawW) / 2;
      const drawY = frameY + (frameH - drawH) / 2;

      ctx.save();
      ctx.beginPath();
      ctx.roundRect(frameX, frameY, frameW, frameH, 34);
      ctx.clip();
      ctx.drawImage(image, drawX, drawY, drawW, drawH);
      ctx.restore();

      ctx.fillStyle = '#24211E';
      ctx.font = '700 44px "Noto Serif SC", serif';
      ctx.fillText(sofaName || '演示品牌沙发', 72, 1298);
      ctx.fillStyle = '#756E66';
      ctx.font = '400 28px "Inter", "Noto Serif SC", sans-serif';
      ctx.fillText(`${fabricLabel} · ${colorLabel}`, 72, 1352);
      ctx.fillText('为您快速确认尺寸、风格和空间氛围。', 72, 1412);

      ctx.fillStyle = '#B58C47';
      ctx.font = '700 28px "Inter", sans-serif';
      ctx.fillText('DEMO 2026 NEW COLLECTION', 72, 1502);

      const a = document.createElement('a');
      a.href = poster.toDataURL('image/png');
      a.download = `DEMO-${sofaName || '顾客'}-分享图.png`;
      a.click();
      onFeedback?.('顾客分享图已生成，可发送给顾客确认。');
    } catch {
      onFeedback?.('生成分享图失败。可能是图片链接跨域限制，请先保存高清效果图使用。');
    }
  };

  const handleLeadSubmit = (e) => {
    e.preventDefault();
    setLeadOpen(false);
    onFeedback?.('预约信息已记录，后续可接入演示门店 CRM 或企微通知');
  };

  return (
    <div className="result-display slide-up" id="result-display">
      <div className="result-header">
        <p className="result-kicker">Step 03</p>
        <h2 className="result-title" id="result-title">专属搭配效果已生成</h2>
        <p className="result-sub">拖动中间滑条，对比原始客厅和 AI 搭配效果。</p>
      </div>

      {/* Before / After slider */}
      <div
        id="compare-slider"
        className="compare-container"
        ref={containerRef}
        onMouseMove={onMouseMove}
        onMouseUp={() => setDragging(false)}
        onMouseLeave={() => setDragging(false)}
        onTouchMove={onTouchMove}
        onTouchEnd={() => setDragging(false)}
      >
        {/* After (result) — full width bottom layer */}
        <img src={resultImage} alt="AI 生成效果图" className="compare-img compare-after" />

        {/* Before (original) — clipped left portion */}
        <div className="compare-before-wrap" style={{ width: `${sliderPos}%` }}>
          <img src={originalImage} alt="原始客厅照片" className="compare-img" />
        </div>

        {/* Divider */}
        <div
          className="compare-divider"
          style={{ left: `${sliderPos}%` }}
          onMouseDown={() => setDragging(true)}
          onTouchStart={() => setDragging(true)}
        >
          <div className="divider-handle">
            <span>‹</span><span>›</span>
          </div>
        </div>

        {/* Labels */}
        <span className="compare-label label-left">原始照片</span>
        <span className="compare-label label-right">AI 效果图</span>
      </div>
      <p className="result-disclaimer">
        AI 效果图用于展示搭配灵感，实际效果可能因光线、角度、尺寸比例和面料色差有所差异，请以实物为准。
      </p>

      {/* Sofa info */}
      <div className="result-info glass-card">
        <div className="result-info-row">
          <span className="result-info-label">选用型号</span>
          <span className="result-info-value">{sofaName}</span>
        </div>
        <div className="result-info-row">
          <span className="result-info-label">面料颜色</span>
          <span className="result-info-value">{fabricLabel} · {colorLabel}</span>
        </div>
        <div className="result-info-row">
          <span className="result-info-label">品牌</span>
          <span className="result-info-value">Demo Sofa AI</span>
        </div>
        <div className="result-info-row">
          <span className="result-info-label">系列</span>
          <span className="result-info-value">2026 年上半年新品</span>
        </div>
      </div>

      {/* Actions */}
      <div className="result-actions">
        <button id="save-btn" className="btn-primary" onClick={handleSave}>
          {saved ? '已保存到相册' : '保存高清效果图'}
        </button>
        <div className="result-secondary-actions">
          <button id="regenerate-btn" className="btn-secondary" onClick={onRegenerate}>
            重新生成
          </button>
          <button id="reset-btn" className="btn-secondary" onClick={onReset}>
            重新选款
          </button>
        </div>
      </div>

      <button
        id="poster-btn"
        className="customer-share-fab"
        type="button"
        onClick={handlePoster}
        aria-label="生成顾客分享图"
      >
        <span>生成顾客分享图</span>
      </button>

      <div className="advisor-card">
        <div>
          <h3>保存该效果图，方便后续沟通确认</h3>
          <p>可结合户型尺寸、面料样册和演示门店现货，进一步确认适合的沙发方案。</p>
        </div>
        <button className="advisor-btn" onClick={() => setLeadOpen(true)}>预约演示门店</button>
      </div>

      {leadOpen && (
        <div className="lead-panel" role="dialog" aria-modal="true" aria-labelledby="lead-title">
          <form className="lead-form" onSubmit={handleLeadSubmit}>
            <div className="lead-form-header">
              <h3 id="lead-title">预约演示门店体验</h3>
              <button type="button" onClick={() => setLeadOpen(false)} aria-label="关闭预约表单">关闭</button>
            </div>
            <label>
              姓名
              <input name="name" type="text" placeholder="请输入称呼" required />
            </label>
            <label>
              联系方式
              <input name="phone" type="tel" placeholder="用于演示联系" required />
            </label>
            <label>
              意向演示门店
              <input name="store" type="text" placeholder="如：Demo Store" />
            </label>
            <button className="btn-primary" type="submit">提交预约</button>
          </form>
        </div>
      )}
    </div>
  );
}
