import { useState, useEffect } from 'react';
import './LoadingOverlay.css';

const MESSAGES = [
  '正在分析空间结构...',
  '正在识别客厅风格...',
  '正在匹配沙发角度...',
  '正在放置沙发...',
  '正在调整光影与阴影...',
  'AI 图片生成可能需要 30-60 秒...',
  '请耐心等待，不要重复提交任务...',
];

export default function LoadingOverlay({ visible, onCancel }) {
  const [msgIdx, setMsgIdx] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!visible) return;
    const msgTimer = setInterval(() => {
      setMsgIdx(i => (i + 1) % MESSAGES.length);
    }, 1400);
    // Smoothly advance progress up to 92% then stall
    const progTimer = setInterval(() => {
      setProgress(p => p >= 92 ? 92 : p + (92 - p) * 0.06 + 0.5);
    }, 250);
    return () => { clearInterval(msgTimer); clearInterval(progTimer); };
  }, [visible]);

  if (!visible) return null;

  return (
    <div className="loading-overlay" id="loading-overlay">
      <div className="loading-card glass-card">
        {/* Animated logo area */}
        <div className="loading-logo">
          <div className="loading-ring" />
          <div className="loading-ring ring-2" />
          <div className="loading-sofa-icon">
            <svg viewBox="0 0 64 40" fill="none">
              <rect x="4" y="18" width="56" height="16" rx="6" fill="currentColor" opacity="0.15"/>
              <rect x="4" y="18" width="12" height="22" rx="4" fill="currentColor" opacity="0.35"/>
              <rect x="48" y="18" width="12" height="22" rx="4" fill="currentColor" opacity="0.35"/>
              <rect x="10" y="10" width="44" height="14" rx="5" fill="currentColor" opacity="0.5"/>
              <rect x="12" y="32" width="8" height="6" rx="2" fill="currentColor" opacity="0.4"/>
              <rect x="44" y="32" width="8" height="6" rx="2" fill="currentColor" opacity="0.4"/>
            </svg>
          </div>
        </div>

        <div className="loading-text-area">
          <h3 className="loading-title">生成任务正在提交</h3>
          <p className="loading-message" key={msgIdx}>{MESSAGES[msgIdx]}</p>
        </div>

        {/* Progress bar */}
        <div className="progress-bar-wrap">
          <div className="progress-bar" style={{ width: `${progress}%` }} />
        </div>
        <p className="progress-hint">{Math.round(progress)}%</p>

        <p className="loading-note">提交后会进入历史任务，处理完成前请勿重复点击生成。</p>

        <button id="loading-cancel-btn" className="loading-cancel" onClick={onCancel}>
          取消生成
        </button>
      </div>
    </div>
  );
}
