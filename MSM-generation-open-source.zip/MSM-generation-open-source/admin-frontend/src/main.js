import './styles.css';

const app = document.querySelector('#app');

const state = {
  loading: true,
  user: null,
  view: 'overview',
  users: [],
  tasks: [],
  products: [],
  settings: [],
  totals: null,
  toast: '',
};

const NAV_ITEMS = [
  { id: 'overview', label: '概览' },
  { id: 'users', label: '用户额度' },
  { id: 'tasks', label: '生成记录' },
  { id: 'products', label: '产品管理' },
  { id: 'settings', label: 'API 配置' },
];

const STRUCTURES = ['直排沙发', 'L型沙发', 'U型沙发', '转角沙发', '功能沙发'];
const SEATS = ['单人位', '双人位', '三人位', '四人位', '五人位', '多人位'];
const MATERIALS = ['真皮', '生态真皮', '亚麻布', '绒布', '棉麻', '科技布'];

const escapeHtml = (value = '') => String(value)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#039;');

const formatDate = (value) => {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('zh-CN', { hour12: false });
};

const statusLabel = (status) => ({
  completed: '已完成',
  processing: '处理中',
  failed: '失败',
  'needs-review': '待查看',
}[status] || status || '-');

const linkForImage = (url, label) => {
  if (!url) return '<span class="muted">-</span>';
  if (String(url).startsWith('data:image/')) return '<span class="muted">已保存原始图片</span>';
  return `<a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${escapeHtml(label)}</a>`;
};

const api = async (url, options = {}) => {
  const response = await fetch(url, {
    credentials: 'include',
    headers: options.body && !options.skipJson
      ? { 'Content-Type': 'application/json', ...(options.headers || {}) }
      : options.headers,
    ...options,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || '请求失败，请稍后再试');
  }
  return data;
};

const setToast = (message) => {
  state.toast = message;
  render();
  window.clearTimeout(setToast.timer);
  setToast.timer = window.setTimeout(() => {
    state.toast = '';
    render();
  }, 4200);
};

const loadAll = async () => {
  const [overview, users, tasks, products, settings] = await Promise.all([
    api('/api/admin/overview'),
    api('/api/admin/users'),
    api('/api/admin/tasks'),
    api('/api/admin/products'),
    api('/api/admin/api-settings'),
  ]);
  state.users = users.users || overview.users || [];
  state.tasks = tasks.tasks || overview.tasks || [];
  state.products = products.products || overview.products || [];
  state.settings = settings.settings || [];
  state.totals = overview.totals || null;
};

const initialize = async () => {
  try {
    const data = await api('/api/admin/me');
    state.user = data.user;
    if (state.user) await loadAll();
  } catch {
    state.user = null;
  } finally {
    state.loading = false;
    render();
  }
};

const renderLogin = () => `
  <main class="login-shell">
    <section class="login-card" aria-labelledby="login-title">
      <div class="brand-mark">DEMO</div>
      <p class="eyebrow">管理员后台</p>
      <h1 id="login-title">演示品牌 AI 沙发搭配管理</h1>
      <p class="login-desc">管理演示门店额度、生成记录、产品素材和 AI 图片 API 配置。</p>
      <form id="login-form" class="form-stack">
        <label>
          管理员账户
          <input name="username" value="admin" autocomplete="username" required />
        </label>
        <label>
          管理员密码
          <input name="password" value="msmadmin2026" type="password" autocomplete="current-password" required />
        </label>
        <button class="primary-btn" type="submit">登录后台</button>
      </form>
      <p class="hint">Demo 管理员账户仅用于本地流程测试，正式部署前建议更换强密码。</p>
    </section>
  </main>
`;

const renderShell = () => `
  <div class="admin-shell">
    <aside class="sidebar">
      <div class="sidebar-brand">
        <span class="brand-mark small">DEMO</span>
        <div>
          <strong>演示品牌管理后台</strong>
          <small>${escapeHtml(state.user?.displayName || state.user?.username || '')}</small>
        </div>
      </div>
      <nav class="side-nav" aria-label="后台导航">
        ${NAV_ITEMS.map(item => `
          <button class="${state.view === item.id ? 'active' : ''}" type="button" data-view="${item.id}">
            ${escapeHtml(item.label)}
          </button>
        `).join('')}
      </nav>
      <button class="ghost-btn logout" type="button" data-action="logout">退出登录</button>
    </aside>
    <main class="content">
      <header class="content-header">
        <div>
          <p class="eyebrow">DEMO Admin</p>
          <h1>${escapeHtml(NAV_ITEMS.find(item => item.id === state.view)?.label || '后台')}</h1>
        </div>
        <button class="ghost-btn" type="button" data-action="refresh">刷新数据</button>
      </header>
      ${renderCurrentView()}
    </main>
    ${state.toast ? `<div class="toast" role="status">${escapeHtml(state.toast)}</div>` : ''}
  </div>
`;

const renderOverview = () => {
  const totals = state.totals || {
    storeUsers: state.users.filter(user => user.role !== 'admin').length,
    tasks: state.tasks.length,
    completedTasks: state.tasks.filter(task => task.status === 'completed').length,
    processingTasks: state.tasks.filter(task => task.status === 'processing').length,
  };
  const todayUsed = state.users.reduce((sum, user) => sum + Number(user.todayUsedCount || 0), 0);

  return `
    <section class="metric-grid" aria-label="核心数据">
      ${metricCard('演示门店用户', totals.storeUsers, '已接入演示门店账号')}
      ${metricCard('今日已用次数', todayUsed, '按提交生成任务扣次')}
      ${metricCard('生成记录', totals.tasks, '最近记录列表')}
      ${metricCard('已完成图片', totals.completedTasks, `${totals.processingTasks || 0} 个处理中`)}
    </section>
    <section class="panel">
      <div class="panel-heading">
        <div>
          <h2>最近生成记录</h2>
          <p>可追踪用户、沙发、扣次日期、AI taskId 和结果图链接。</p>
        </div>
        <button class="text-btn" type="button" data-view="tasks">查看全部</button>
      </div>
      ${renderTasksTable(state.tasks.slice(0, 6))}
    </section>
  `;
};

const metricCard = (label, value, note) => `
  <article class="metric-card">
    <span>${escapeHtml(label)}</span>
    <strong>${escapeHtml(value)}</strong>
    <small>${escapeHtml(note)}</small>
  </article>
`;

const renderUsers = () => `
  <section class="panel">
    <div class="panel-heading">
      <div>
        <h2>演示门店账号与生成额度</h2>
        <p>这里可以同时修改“每日额度”和“今日已使用次数”。</p>
      </div>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>用户名称</th>
            <th>账户名</th>
            <th>角色</th>
            <th>每日额度</th>
            <th>今日已用</th>
            <th>今日剩余</th>
            <th>最近生成</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          ${state.users.map(user => `
            <tr>
              <td>${escapeHtml(user.displayName)}</td>
              <td><code>${escapeHtml(user.username)}</code></td>
              <td>${user.role === 'admin' ? '管理员' : '演示门店用户'}</td>
              <td>
                <input class="table-input" name="dailyLimit" form="quota-${user.id}" type="number" min="0" value="${escapeHtml(user.dailyLimit)}" />
              </td>
              <td>
                <input class="table-input" name="usedCount" form="quota-${user.id}" type="number" min="0" value="${escapeHtml(user.todayUsedCount)}" />
              </td>
              <td>${escapeHtml(user.todayRemaining)}</td>
              <td>${formatDate(user.latestGenerationAt)}</td>
              <td>
                <form id="quota-${user.id}" data-user-id="${user.id}" class="inline-form">
                  <button class="small-primary" type="submit">保存</button>
                </form>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  </section>
`;

const renderTasks = () => `
  <section class="panel">
    <div class="panel-heading">
      <div>
        <h2>生成记录</h2>
        <p>包含用户、状态、扣次归属、沙发信息、图片引用、配置快照和 AI taskId。</p>
      </div>
    </div>
    ${renderTasksTable(state.tasks)}
  </section>
`;

const renderTasksTable = (tasks) => {
  if (!tasks.length) {
    return '<div class="empty-state">暂无生成记录</div>';
  }

  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>用户名称</th>
            <th>账户名</th>
            <th>生成时间</th>
            <th>任务状态</th>
            <th>次数归属</th>
            <th>沙发信息</th>
            <th>生成图片</th>
            <th>原始客厅图</th>
            <th>AI taskId</th>
            <th>配置快照</th>
          </tr>
        </thead>
        <tbody>
          ${tasks.map(task => `
            <tr>
              <td>${escapeHtml(task.displayName || '-')}</td>
              <td><code>${escapeHtml(task.username || '-')}</code></td>
              <td>${formatDate(task.submittedAt || task.createdAt)}</td>
              <td><span class="status status-${escapeHtml(task.status)}">${escapeHtml(statusLabel(task.status))}</span></td>
              <td>${escapeHtml(task.quotaOwner || task.chargedDate || '-')}</td>
              <td>
                <strong>${escapeHtml(task.sofaName || '-')}</strong>
                <small>${escapeHtml(task.sofaId || '')}</small>
              </td>
              <td>${linkForImage(task.imageUrl, '打开结果图')}</td>
              <td>${linkForImage(task.originalImage, '打开原图')}</td>
              <td><code>${escapeHtml(task.providerTaskId || task.clientTaskId || '-')}</code></td>
              <td>
                <details>
                  <summary>查看</summary>
                  <pre>${escapeHtml(JSON.stringify(task.configSnapshot || {}, null, 2))}</pre>
                </details>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
};

const renderProducts = () => `
  <div class="split-layout">
    <section class="panel">
      <div class="panel-heading">
        <div>
          <h2>新增产品</h2>
          <p>上传后会同步到演示门店端沙发选择模块。系列可选填，填写后会自动进入系列筛选。</p>
        </div>
      </div>
      <form id="product-form" class="product-form">
        <div class="form-grid">
          ${inputField('modelId', '产品型号', '如 A101', true)}
          ${inputField('name', '产品名称', '如 演示品牌 A101', false)}
          ${selectField('structure', '结构', STRUCTURES)}
          ${selectField('seats', '座位', SEATS, '三人位')}
          ${selectField('material', '面料/材质', MATERIALS)}
          ${inputField('seriesLabel', '系列信息', '如 2026年春夏季新款', false)}
        </div>
        <label class="checkbox-row">
          <input name="hasFunction" type="checkbox" />
          <span>功能款沙发</span>
        </label>
        <label>
          产品规格信息
          <textarea name="specText" rows="5" placeholder="可粘贴型号规格、尺寸、组合、材质说明等"></textarea>
        </label>
        <div class="upload-grid">
          <label class="file-drop">
            <strong>宣传图</strong>
            <span>演示门店端卡片展示图</span>
            <input name="catalogImage" type="file" accept="image/*" required />
          </label>
          <label class="file-drop">
            <strong>白底图</strong>
            <span>AI 生成使用的产品参考图</span>
            <input name="productImage" type="file" accept="image/*" required />
          </label>
        </div>
        <button class="primary-btn" type="submit">上传并同步产品</button>
      </form>
    </section>
    <section class="panel">
      <div class="panel-heading">
        <div>
          <h2>后台新增产品</h2>
          <p>${state.products.length} 款产品由后台维护。</p>
        </div>
      </div>
      <div class="product-list">
        ${state.products.length ? state.products.map(product => `
          <article class="product-card">
            <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy" />
            <div>
              <strong>${escapeHtml(product.name)}</strong>
              <span>${escapeHtml(product.structure)} · ${escapeHtml(product.seats)} · ${escapeHtml(product.material)}</span>
              <small>${escapeHtml(product.seriesLabel || '未填写系列')}</small>
            </div>
          </article>
        `).join('') : '<div class="empty-state">还没有后台新增产品</div>'}
      </div>
    </section>
  </div>
`;

const inputField = (name, label, placeholder, required) => `
  <label>
    ${escapeHtml(label)}
    <input name="${escapeHtml(name)}" placeholder="${escapeHtml(placeholder)}" ${required ? 'required' : ''} />
  </label>
`;

const selectField = (name, label, options, selected = options[0]) => `
  <label>
    ${escapeHtml(label)}
    <select name="${escapeHtml(name)}">
      ${options.map(option => `
        <option value="${escapeHtml(option)}" ${option === selected ? 'selected' : ''}>${escapeHtml(option)}</option>
      `).join('')}
    </select>
  </label>
`;

const renderSettings = () => `
  <section class="panel narrow-panel">
    <div class="panel-heading">
      <div>
        <h2>AI 图片 API 配置</h2>
        <p>修改后后端会立即按数据库配置调用接口。API Key 留空表示保持不变。</p>
      </div>
    </div>
    <form id="settings-form" class="form-stack">
      ${state.settings.map(setting => `
        <label>
          ${escapeHtml(setting.label)}
          <input
            name="${escapeHtml(setting.key)}"
            type="${setting.secret ? 'password' : 'text'}"
            value="${escapeHtml(setting.value || '')}"
            placeholder="${escapeHtml(setting.secret ? (setting.maskedValue || '未配置') : '')}"
          />
          <small>${escapeHtml(setting.description)}</small>
        </label>
      `).join('')}
      <button class="primary-btn" type="submit">保存 API 配置</button>
    </form>
  </section>
`;

const renderCurrentView = () => ({
  overview: renderOverview,
  users: renderUsers,
  tasks: renderTasks,
  products: renderProducts,
  settings: renderSettings,
}[state.view] || renderOverview)();

const render = () => {
  if (state.loading) {
    app.innerHTML = '<main class="loading-page">正在进入管理后台...</main>';
    return;
  }
  app.innerHTML = state.user ? renderShell() : renderLogin();
};

const fileToDataUrl = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(reader.result);
  reader.onerror = () => reject(new Error('读取图片失败'));
  reader.readAsDataURL(file);
});

app.addEventListener('click', async (event) => {
  const viewButton = event.target.closest('[data-view]');
  if (viewButton) {
    state.view = viewButton.dataset.view;
    render();
    return;
  }

  const actionButton = event.target.closest('[data-action]');
  if (!actionButton) return;

  if (actionButton.dataset.action === 'logout') {
    await api('/api/admin/logout', { method: 'POST' });
    state.user = null;
    render();
    return;
  }

  if (actionButton.dataset.action === 'refresh') {
    await loadAll();
    setToast('后台数据已刷新');
  }
});

app.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.target;

  try {
    if (form.id === 'login-form') {
      const formData = new FormData(form);
      const data = await api('/api/admin/login', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData.entries())),
      });
      state.user = data.user;
      await loadAll();
      setToast('已进入管理员后台');
      return;
    }

    if (form.id?.startsWith('quota-')) {
      const formData = new FormData(form);
      const userId = form.dataset.userId;
      const payload = {
        dailyLimit: Number(formData.get('dailyLimit')),
        usedCount: Number(formData.get('usedCount')),
      };
      const data = await api(`/api/admin/users/${userId}/quota`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      });
      state.users = data.users || state.users;
      setToast('用户额度已更新');
      return;
    }

    if (form.id === 'product-form') {
      const formData = new FormData(form);
      const catalogFile = formData.get('catalogImage');
      const productFile = formData.get('productImage');
      const payload = {
        modelId: formData.get('modelId'),
        name: formData.get('name'),
        structure: formData.get('structure'),
        seats: formData.get('seats'),
        material: formData.get('material'),
        seriesLabel: formData.get('seriesLabel'),
        specText: formData.get('specText'),
        hasFunction: formData.get('hasFunction') === 'on',
        catalogImage: {
          filename: catalogFile?.name,
          dataUrl: await fileToDataUrl(catalogFile),
        },
        productImage: {
          filename: productFile?.name,
          dataUrl: await fileToDataUrl(productFile),
        },
      };
      const data = await api('/api/admin/products', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      state.products = data.catalog?.products || state.products;
      form.reset();
      setToast('产品已上传，演示门店端可刷新后查看');
      return;
    }

    if (form.id === 'settings-form') {
      const formData = new FormData(form);
      const settings = {};
      state.settings.forEach(setting => {
        const value = formData.get(setting.key);
        if (setting.secret && !String(value || '').trim()) return;
        settings[setting.key] = value;
      });
      const data = await api('/api/admin/api-settings', {
        method: 'PATCH',
        body: JSON.stringify({ settings }),
      });
      state.settings = data.settings || state.settings;
      setToast('API 配置已保存');
    }
  } catch (error) {
    setToast(error.message || '操作失败');
  }
});

initialize();
