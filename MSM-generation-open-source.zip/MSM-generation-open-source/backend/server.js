/**
 * DEMO-generation backend
 * Customer app API + admin API + image generation proxy
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  createSession,
  deleteSession,
  deleteTaskForUser,
  findTaskForUser,
  findUserById,
  findUserByUsername,
  getAdminOverview,
  getApiSettingsMap,
  getDailyUsage,
  getUserBySession,
  initDb,
  listApiSettings,
  listProducts,
  listTasksForAdmin,
  listTasksForUser,
  listUsersWithUsage,
  releaseDailyQuota,
  reserveDailyQuota,
  updateApiSettings,
  updateTaskForUser,
  updateUserQuota,
  upsertProduct,
  upsertTask,
  verifyPassword,
} from './db.js';

dotenv.config();
initDb();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3001', 10);
const SESSION_COOKIE = 'msm_session';
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const PRODUCT_UPLOADS_DIR = path.join(UPLOADS_DIR, 'products');
const GENERATION_UPLOADS_DIR = path.join(UPLOADS_DIR, 'generation');

fs.mkdirSync(PRODUCT_UPLOADS_DIR, { recursive: true });
fs.mkdirSync(GENERATION_UPLOADS_DIR, { recursive: true });

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use('/uploads', express.static(UPLOADS_DIR));

const localTasks = new Map();

const parseCookies = (cookieHeader = '') => Object.fromEntries(
  cookieHeader
    .split(';')
    .map(part => part.trim())
    .filter(Boolean)
    .map(part => {
      const index = part.indexOf('=');
      if (index === -1) return [part, ''];
      return [part.slice(0, index), decodeURIComponent(part.slice(index + 1))];
    })
);

const setSessionCookie = (res, session) => {
  res.cookie(SESSION_COOKIE, session.id, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: session.maxAgeSeconds * 1000,
  });
};

const clearSessionCookie = (res) => {
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
  });
};

const getSessionId = (req) => parseCookies(req.headers.cookie || '')[SESSION_COOKIE];

const authPayload = (user) => ({
  user: {
    id: user.id,
    username: user.username,
    displayName: user.displayName || user.display_name || user.username,
    role: user.role || 'store',
  },
  quota: getDailyUsage(user.id),
});

const requireAuth = (req, res, next) => {
  const user = getUserBySession(getSessionId(req));
  if (!user || user.role === 'admin') {
    return res.status(401).json({ error: '请先登录演示门店账号后再使用 AI 沙发搭配功能' });
  }
  req.user = user;
  return next();
};

const requireAdmin = (req, res, next) => {
  const user = getUserBySession(getSessionId(req));
  if (!user) {
    return res.status(401).json({ error: '请先登录管理员账号' });
  }
  if (user.role !== 'admin') {
    return res.status(403).json({ error: '当前账号没有管理员权限' });
  }
  req.user = user;
  return next();
};

const numberFromSetting = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const getProviderConfig = () => {
  const settings = getApiSettingsMap();
  return {
    apiKey: settings.banana_api_key || process.env.BANANA_API_KEY || '',
    apiUrl: settings.banana_api_url || process.env.BANANA_API_URL || 'https://www.qh-aigc.com/api/v1/images/edits',
    queryUrl: settings.banana_query_url || process.env.BANANA_QUERY_URL || 'https://www.qh-aigc.com/api/v1/ai/result',
    model: settings.banana_model || process.env.BANANA_MODEL || '【限免】gpt-image-2',
    aspectRatio: settings.banana_aspect_ratio || process.env.BANANA_ASPECT_RATIO || '16:9',
    resolution: settings.banana_resolution || process.env.BANANA_RESOLUTION || '2K',
    webhookUrl: settings.banana_webhook_url || process.env.BANANA_WEBHOOK_URL || '',
    publicBaseUrl: (settings.public_base_url || process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, ''),
    pollIntervalMs: numberFromSetting(settings.banana_poll_interval_ms || process.env.BANANA_POLL_INTERVAL_MS, 3000),
    pollTimeoutMs: numberFromSetting(settings.banana_poll_timeout_ms || process.env.BANANA_POLL_TIMEOUT_MS, 75000),
  };
};

const isQhProvider = (config) => {
  const apiUrl = String(config?.apiUrl || '');
  const queryUrl = String(config?.queryUrl || '');
  return apiUrl.includes('qh-aigc.com/api/v1') || queryUrl.includes('qh-aigc.com/api/v1');
};

const qhImageSize = (config) => {
  const value = String(config?.resolution || '').trim();
  if (/^\d+x\d+$/i.test(value)) return value;
  if (/^(\d+)px$/i.test(value)) {
    const size = value.match(/^(\d+)px$/i)?.[1];
    return `${size}x${size}`;
  }
  return '512x512';
};

const extractImageUrl = (result) => {
  const candidates = [
    result?.imageUrl,
    result?.imageURL,
    result?.url,
    result?.data?.imageUrl,
    result?.data?.imageURL,
    result?.data?.url,
    result?.result?.imageUrl,
    result?.result?.url,
    result?.output?.imageUrl,
    result?.output?.url,
    result?.result?.output?.imageUrl,
    result?.result?.output?.url,
    result?.queue_status?.data?.url,
    result?.queue_status?.data?.imageUrl,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim()) {
      return candidate.trim();
    }
  }

  const arrays = [
    result?.data,
    result?.results,
    result?.imageUrls,
    result?.image_urls,
    result?.images,
    result?.data?.results,
    result?.data?.imageUrls,
    result?.data?.images,
    result?.result?.results,
    result?.result?.imageUrls,
    result?.result?.images,
    result?.result?.data?.results,
    result?.output?.imageUrls,
    result?.output?.images,
    result?.output?.results,
    result?.output,
    result?.output_content,
    result?.data?.output,
    result?.data?.output_content,
    result?.queue_status?.data?.output,
    result?.queue_status?.data?.output_content,
  ];

  for (const list of arrays) {
    if (!Array.isArray(list)) continue;
    const first = list.find(item => {
      if (typeof item === 'string') return item.trim();
      return item?.url || item?.imageUrl;
    });
    if (typeof first === 'string') return first.trim();
    if (first?.url) return first.url;
    if (first?.imageUrl) return first.imageUrl;
    if (first?.b64_json) return `data:image/png;base64,${first.b64_json}`;
  }

  return null;
};

const extractTaskId = (result) => {
  const candidates = [
    result?.taskId,
    result?.task_id,
    result?.id,
    result?.data?.taskId,
    result?.data?.task_id,
    result?.data?.id,
    result?.data?.taskId,
    result?.result?.taskId,
    result?.result?.task_id,
    result?.result?.id,
    result?.result?.task_id_str,
    result?.result?.requestId,
    result?.result?.request_id,
    result?.result?.clientId,
    result?.chargeTransactionId,
    result?.queue_status?.task_id,
  ];

  const match = candidates.find(candidate => typeof candidate === 'string' && candidate.trim());
  return match ? match.trim() : null;
};

const extractStatus = (result) => {
  const candidates = [
    result?.status,
    result?.data?.status,
    result?.result?.status,
    result?.output?.status,
    result?.queue_status?.status,
    result?.queue_status?.data?.status,
  ];
  const match = candidates.find(candidate => typeof candidate === 'string' && candidate.trim());
  return match ? match.trim().toUpperCase() : '';
};

const extractErrorMessage = (result) => {
  const candidates = [
    result?.error,
    result?.errorMessage,
    result?.message,
    result?.failedReason,
    result?.data?.error,
    result?.data?.errorMessage,
    result?.result?.error,
    result?.result?.errorMessage,
    result?.result?.failedReason,
    result?.queue_status?.message,
    result?.queue_status?.data?.message,
  ];

  const match = candidates.find(candidate => {
    if (typeof candidate === 'string') return candidate.trim();
    return candidate && typeof candidate === 'object' && Object.keys(candidate).length > 0;
  });

  if (!match) return '';
  return typeof match === 'string' ? match : JSON.stringify(match);
};

const buildTaskPayload = ({ status, clientTaskId, providerTaskId, imageUrl, raw, message }) => ({
  status,
  clientTaskId,
  providerTaskId,
  imageUrl: imageUrl || null,
  message,
  raw,
});

const imageReferenceSummary = (references) => references.map((reference, index) => {
  const value = String(reference || '');
  return {
    index: index + 1,
    type: value.startsWith('data:image/') ? 'data-url' : value.startsWith('http') ? 'url' : 'unknown',
    length: value.length,
  };
});

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const postJsonToProvider = async (url, payload, apiKey, headers = {}) => {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      ...headers,
    },
    body: JSON.stringify(payload),
  });

  let result;
  try {
    result = await response.json();
  } catch {
    result = { error: '接口没有返回有效 JSON' };
  }

  if (!response.ok) {
    const errMsg = result?.error?.message || result?.error || result?.message || '外部 API 请求失败';
    const error = new Error(typeof errMsg === 'string' ? errMsg : JSON.stringify(errMsg));
    error.statusCode = response.status;
    error.raw = result;
    throw error;
  }

  return result;
};

const queryBananaTask = (taskId, config = getProviderConfig()) => (
  isQhProvider(config)
    ? queryQhTask(taskId, config)
    : postJsonToProvider(config.queryUrl, { taskId }, config.apiKey)
);

const queryQhTask = async (taskId, config = getProviderConfig()) => {
  const baseUrl = String(config.queryUrl || '').replace(/\/+$/, '');
  const queryUrl = baseUrl.includes(':taskId')
    ? baseUrl.replace(':taskId', encodeURIComponent(taskId))
    : baseUrl.endsWith(taskId)
      ? baseUrl
      : `${baseUrl}/${encodeURIComponent(taskId)}`;

  const response = await fetch(queryUrl, {
    headers: {
      'Authorization': `Bearer ${config.apiKey}`,
    },
  });

  let result;
  try {
    result = await response.json();
  } catch {
    result = { error: '接口没有返回有效 JSON' };
  }

  if (!response.ok) {
    const errMsg = result?.error?.message || result?.error || result?.message || '外部 API 请求失败';
    const error = new Error(typeof errMsg === 'string' ? errMsg : JSON.stringify(errMsg));
    error.statusCode = response.status;
    error.raw = result;
    throw error;
  }

  return result;
};

const submitImageGeneration = (config, { prompt, references, clientTaskId }) => {
  if (isQhProvider(config)) {
    return postJsonToProvider(
      config.apiUrl,
      {
        model: config.model,
        prompt,
        image: references.length === 1 ? references[0] : references,
        resolution: config.resolution,
        aspect_ratio: config.aspectRatio,
      },
      config.apiKey,
      { 'x-async': 'true' }
    );
  }

  const payload = {
    prompt,
    imageUrls: references,
    aspectRatio: config.aspectRatio,
    resolution: config.resolution,
    clientTaskId,
  };

  if (config.webhookUrl) payload.webhookUrl = config.webhookUrl;
  return postJsonToProvider(config.apiUrl, payload, config.apiKey);
};

const pollBananaTask = async (taskId, config = getProviderConfig()) => {
  const startedAt = Date.now();
  let lastRaw = null;

  while (Date.now() - startedAt < config.pollTimeoutMs) {
    await sleep(config.pollIntervalMs);
    const raw = await queryBananaTask(taskId, config);
    lastRaw = raw;

    const status = extractStatus(raw);
    const imageUrl = extractImageUrl(raw);

    if ((status === 'SUCCESS' || status === 'COMPLETED') && imageUrl) {
      return {
        done: true,
        status: 'completed',
        imageUrl,
        raw,
        message: '生成完成',
      };
    }

    if (status === 'FAILED' || status === 'FAILURE' || status === 'TIMEOUT' || status === 'CANCELED' || status === 'CANCELLED') {
      return {
        done: true,
        status: 'failed',
        imageUrl: null,
        raw,
        message: extractErrorMessage(raw) || `任务结束但状态为 ${status}`,
      };
    }
  }

  return {
    done: false,
    status: 'processing',
    imageUrl: null,
    raw: lastRaw,
    message: '任务仍在处理中，请稍后刷新历史任务或到调用记录查看。',
  };
};

const maskSecret = (value = '') => {
  if (!value) return '';
  if (value.length <= 10) return '已配置';
  return `${value.slice(0, 6)}...${value.slice(-4)}`;
};

const effectiveSecretValue = (setting) => {
  if (setting.value) return setting.value;
  if (setting.key === 'banana_api_key') return process.env.BANANA_API_KEY || '';
  return '';
};

const publicApiSettings = () => listApiSettings().map(setting => {
  const effectiveValue = setting.secret ? effectiveSecretValue(setting) : setting.value;
  return {
    ...setting,
    value: setting.secret ? '' : setting.value,
    maskedValue: setting.secret ? maskSecret(effectiveValue) : setting.value,
    hasValue: Boolean(effectiveValue),
  };
});

const safeSegment = (value) => String(value || '')
  .trim()
  .replace(/[^a-zA-Z0-9_-]/g, '-')
  .replace(/-+/g, '-')
  .replace(/^-|-$/g, '')
  .slice(0, 80);

const extensionFromMime = (mime, filename = '') => {
  const ext = path.extname(filename).toLowerCase();
  if (ext && ['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) return ext;
  if (mime === 'image/png') return '.png';
  if (mime === 'image/webp') return '.webp';
  return '.jpg';
};

const saveDataUrlImage = ({ dataUrl, filename, modelId, kind }) => {
  const match = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) {
    const error = new Error('请上传有效的图片文件');
    error.statusCode = 400;
    throw error;
  }

  const [, mime, base64] = match;
  const safeModelId = safeSegment(modelId).toUpperCase();
  if (!safeModelId) {
    const error = new Error('产品型号不能为空');
    error.statusCode = 400;
    throw error;
  }

  const folder = path.join(PRODUCT_UPLOADS_DIR, safeModelId);
  fs.mkdirSync(folder, { recursive: true });

  const ext = extensionFromMime(mime, filename);
  const targetName = `${kind}-${Date.now()}-${cryptoRandomSuffix()}${ext}`;
  const targetPath = path.join(folder, targetName);
  fs.writeFileSync(targetPath, Buffer.from(base64, 'base64'));
  return `/uploads/products/${safeModelId}/${targetName}`;
};

const cryptoRandomSuffix = () => Math.random().toString(36).slice(2, 8);

const imageExtFromMime = (mime) => {
  if (mime === 'image/png') return '.png';
  if (mime === 'image/webp') return '.webp';
  return '.jpg';
};

const saveGenerationDataUrl = ({ dataUrl, clientTaskId, index }) => {
  const match = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;

  const [, mime, base64] = match;
  const safeTaskId = safeSegment(clientTaskId);
  const folder = path.join(GENERATION_UPLOADS_DIR, safeTaskId);
  fs.mkdirSync(folder, { recursive: true });

  const filename = `ref-${index + 1}${imageExtFromMime(mime)}`;
  fs.writeFileSync(path.join(folder, filename), Buffer.from(base64, 'base64'));
  return `/uploads/generation/${safeTaskId}/${filename}`;
};

const parseImageDataUrl = (dataUrl) => {
  const match = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;
  const [, mime, base64] = match;
  return { mime, buffer: Buffer.from(base64, 'base64') };
};

const qhUploadUrl = (config) => {
  const parsed = new URL(config.apiUrl);
  return `${parsed.origin}/api/v1/files/upload`;
};

const uploadDataUrlToQh = async ({ dataUrl, config, clientTaskId, index }) => {
  const parsed = parseImageDataUrl(dataUrl);
  if (!parsed) {
    const error = new Error('请上传有效的图片文件');
    error.statusCode = 400;
    throw error;
  }

  const form = new FormData();
  const ext = imageExtFromMime(parsed.mime);
  const filename = `${safeSegment(clientTaskId) || 'msm'}-${index + 1}${ext}`;
  form.append('file', new Blob([parsed.buffer], { type: parsed.mime }), filename);

  const response = await fetch(qhUploadUrl(config), {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.apiKey}`,
    },
    body: form,
  });

  let result;
  try {
    result = await response.json();
  } catch {
    result = { error: '文件上传接口没有返回有效 JSON' };
  }

  if (!response.ok) {
    const errMsg = result?.error?.message || result?.error || result?.message || '文件上传失败';
    const error = new Error(typeof errMsg === 'string' ? errMsg : JSON.stringify(errMsg));
    error.statusCode = response.status;
    error.raw = result;
    throw error;
  }

  const uploadedUrl = result?.url || result?.data?.url || result?.file?.url || result?.data?.file?.url;
  if (!uploadedUrl) {
    const error = new Error('文件上传成功但未返回图片 URL');
    error.statusCode = 502;
    error.raw = result;
    throw error;
  }

  return uploadedUrl;
};

const requestBaseUrl = (req) => {
  const host = req.get('host') || '';
  if (!host || host.includes('127.0.0.1') || host.includes('localhost')) return '';
  const proto = req.get('x-forwarded-proto') || req.protocol || 'https';
  return `${proto}://${host}`.replace(/\/+$/, '');
};

const materializeImageReferences = async ({ req, references, clientTaskId, providerConfig }) => {
  const baseUrl = providerConfig.publicBaseUrl || requestBaseUrl(req);
  const hasDataUrl = references.some(reference => String(reference || '').startsWith('data:image/'));

  if (hasDataUrl && isQhProvider(providerConfig)) {
    const uploaded = [];
    for (let index = 0; index < references.length; index += 1) {
      const value = String(references[index] || '');
      if (value.startsWith('data:image/')) {
        uploaded.push(await uploadDataUrlToQh({
          dataUrl: value,
          config: providerConfig,
          clientTaskId,
          index,
        }));
      } else {
        uploaded.push(value);
      }
    }
    return uploaded;
  }

  if (hasDataUrl && !baseUrl) {
    const error = new Error('当前图片是本地上传文件，AI 图片接口需要可公网访问的图片 URL。请先在管理员端 API 配置里填写“公网图片访问地址”，或部署后再生成。');
    error.statusCode = 400;
    throw error;
  }

  return references.map((reference, index) => {
    const value = String(reference || '');
    if (!value.startsWith('data:image/')) return value;
    const localPath = saveGenerationDataUrl({ dataUrl: value, clientTaskId, index });
    return `${baseUrl}${localPath}`;
  });
};

const catalogPayload = () => {
  const products = listProducts();
  const structureCategories = [...new Set(products.flatMap(product => product.structureTags || product.structure).filter(Boolean))];
  const seatCategories = [...new Set(products.map(product => product.seats).filter(Boolean))];
  const seriesCategories = [...new Set(products.map(product => product.seriesLabel).filter(Boolean))]
    .map(label => ({ label, year: label }));

  return {
    products,
    structureCategories,
    seatCategories,
    seriesCategories,
  };
};

// ── 演示门店用户路由 ───────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = findUserByUsername(username?.trim());

  if (!user || !verifyPassword(password || '', user)) {
    return res.status(401).json({ error: '账户名或密码不正确' });
  }

  if (user.role === 'admin') {
    return res.status(403).json({ error: '管理员账号请从管理员入口登录' });
  }

  const session = createSession(user.id);
  setSessionCookie(res, session);
  return res.json(authPayload({
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    role: user.role,
  }));
});

app.get('/api/auth/me', (req, res) => {
  const user = getUserBySession(getSessionId(req));
  if (!user || user.role === 'admin') return res.json({ user: null, quota: null });
  return res.json(authPayload(user));
});

app.post('/api/auth/logout', (req, res) => {
  deleteSession(getSessionId(req));
  clearSessionCookie(res);
  res.json({ ok: true });
});

app.get('/api/products', requireAuth, (_req, res) => {
  res.json(catalogPayload());
});

app.get('/api/history', requireAuth, (req, res) => {
  res.json({ tasks: listTasksForUser(req.user.id), quota: getDailyUsage(req.user.id) });
});

app.patch('/api/history/:clientTaskId', requireAuth, (req, res) => {
  const task = updateTaskForUser({
    userId: req.user.id,
    clientTaskId: req.params.clientTaskId,
    status: req.body.status,
    imageUrl: req.body.imageUrl,
    message: req.body.message,
  });
  res.json({ task, tasks: listTasksForUser(req.user.id), quota: getDailyUsage(req.user.id) });
});

app.delete('/api/history/:clientTaskId', requireAuth, (req, res) => {
  deleteTaskForUser({ userId: req.user.id, clientTaskId: req.params.clientTaskId });
  res.json({ ok: true, tasks: listTasksForUser(req.user.id), quota: getDailyUsage(req.user.id) });
});

app.get('/api/download-image', requireAuth, async (req, res) => {
  const imageUrl = String(req.query.url || '').trim();
  const filename = String(req.query.filename || 'DEMO-效果图.jpg')
    .replace(/[\\/:*?"<>|]+/g, '-')
    .slice(0, 120);

  if (!/^https?:\/\//i.test(imageUrl) && !imageUrl.startsWith('data:image/')) {
    return res.status(400).json({ error: '请提供有效的图片 URL' });
  }

  try {
    if (imageUrl.startsWith('data:image/')) {
      const parsed = parseImageDataUrl(imageUrl);
      if (!parsed) return res.status(400).json({ error: '图片数据无效' });
      res.setHeader('Content-Type', parsed.mime);
      res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
      return res.send(parsed.buffer);
    }

    const response = await fetch(imageUrl);
    if (!response.ok) {
      return res.status(502).json({ error: '下载图片失败，请稍后再试' });
    }

    const contentType = response.headers.get('content-type') || 'image/jpeg';
    const arrayBuffer = await response.arrayBuffer();
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    return res.send(Buffer.from(arrayBuffer));
  } catch (error) {
    console.error('[Download Image Error]', error);
    return res.status(500).json({ error: '下载图片失败，请稍后再试' });
  }
});

app.post('/api/generate-image', requireAuth, async (req, res) => {
  const { prompt, base64Image, imageUrls = [], metadata = {} } = req.body;
  const providerConfig = getProviderConfig();

  if (!prompt) {
    return res.status(400).json({ error: '请提供 prompt' });
  }

  if (!providerConfig.apiKey) {
    return res.status(500).json({ error: '后端未配置图片生成 API Key，请先到管理员端配置' });
  }

  const references = [...imageUrls];
  if (base64Image) references.unshift(base64Image);

  if (references.length === 0) {
    return res.status(400).json({ error: '请至少提供一张参考图' });
  }

  const clientTaskId = `msm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const submittedAt = new Date().toISOString();
  let quota;
  let acceptedProviderTaskId = null;

  try {
    quota = reserveDailyQuota(req.user.id);
  } catch (error) {
    return res.status(error.statusCode || 429).json({
      error: error.message,
      quota: error.quota || getDailyUsage(req.user.id),
    });
  }

  let providerReferences;
  try {
    providerReferences = await materializeImageReferences({
      req,
      references,
      clientTaskId,
      providerConfig,
    });
  } catch (error) {
    return res.status(error.statusCode || 400).json({
      error: error.message,
      quota: getDailyUsage(req.user.id),
    });
  }

  console.log(`[generate-image] image provider=${isQhProvider(providerConfig) ? 'qh-aigc' : 'banana2'}, task=${clientTaskId}, refs=${providerReferences.length}, resolution=${providerConfig.resolution}`);
  console.log('[generate-image] ref summary', imageReferenceSummary(providerReferences));

  try {
    const result = await submitImageGeneration(providerConfig, {
      prompt,
      references: providerReferences,
      clientTaskId,
    });

    console.log('[Image API Raw Response]', JSON.stringify(result).slice(0, 300));

    const imageUrl = extractImageUrl(result);
    const providerTaskId = extractTaskId(result);
    acceptedProviderTaskId = providerTaskId;
    const submitStatus = extractStatus(result);

    if (imageUrl) {
      const task = buildTaskPayload({
        status: 'completed',
        clientTaskId,
        providerTaskId,
        imageUrl,
        raw: result,
        message: '生成完成',
      });
      localTasks.set(clientTaskId, task);
      upsertTask({
        userId: req.user.id,
        clientTaskId,
        providerTaskId,
        sofaId: metadata.sofaId,
        sofaName: metadata.sofaName,
        status: task.status,
        imageUrl: task.imageUrl,
        originalImage: metadata.originalImage || base64Image,
        configSnapshot: metadata.configSnapshot,
        message: task.message,
        rawResponse: task.raw,
        chargedDate: quota.date,
        submittedAt,
        completedAt: new Date().toISOString(),
      });
      return res.json({ ...task, quota: getDailyUsage(req.user.id) });
    }

    if (!providerTaskId) {
      releaseDailyQuota(req.user.id, quota.date);
      const task = buildTaskPayload({
        status: 'failed',
        clientTaskId,
        providerTaskId: null,
        raw: result,
        message: '提交成功但未返回 taskId，无法查询生成结果。',
      });
      localTasks.set(clientTaskId, task);
      upsertTask({
        userId: req.user.id,
        clientTaskId,
        providerTaskId: null,
        sofaId: metadata.sofaId,
        sofaName: metadata.sofaName,
        status: task.status,
        imageUrl: null,
        originalImage: metadata.originalImage || base64Image,
        configSnapshot: metadata.configSnapshot,
        message: task.message,
        rawResponse: task.raw,
        chargedDate: null,
        submittedAt,
      });
      return res.status(502).json({ ...task, quota: getDailyUsage(req.user.id) });
    }

    if (submitStatus === 'FAILED' || submitStatus === 'FAILURE') {
      releaseDailyQuota(req.user.id, quota.date);
      const task = buildTaskPayload({
        status: 'failed',
        clientTaskId,
        providerTaskId,
        raw: result,
        message: extractErrorMessage(result) || '任务提交失败',
      });
      localTasks.set(clientTaskId, task);
      upsertTask({
        userId: req.user.id,
        clientTaskId,
        providerTaskId,
        sofaId: metadata.sofaId,
        sofaName: metadata.sofaName,
        status: task.status,
        imageUrl: null,
        originalImage: metadata.originalImage || base64Image,
        configSnapshot: metadata.configSnapshot,
        message: task.message,
        rawResponse: task.raw,
        chargedDate: null,
        submittedAt,
      });
      return res.status(502).json({ ...task, quota: getDailyUsage(req.user.id) });
    }

    console.log(`[generate-image] polling query task=${providerTaskId}`);
    const pollResult = await pollBananaTask(providerTaskId, providerConfig);
    const normalizedTask = buildTaskPayload({
      status: pollResult.status,
      clientTaskId,
      providerTaskId,
      imageUrl: pollResult.imageUrl,
      raw: pollResult.raw || result,
      message: pollResult.message,
    });

    localTasks.set(clientTaskId, normalizedTask);
    upsertTask({
      userId: req.user.id,
      clientTaskId,
      providerTaskId,
      sofaId: metadata.sofaId,
      sofaName: metadata.sofaName,
      status: normalizedTask.status,
      imageUrl: normalizedTask.imageUrl,
      originalImage: metadata.originalImage || base64Image,
      configSnapshot: metadata.configSnapshot,
      message: normalizedTask.message,
      rawResponse: normalizedTask.raw,
      chargedDate: quota.date,
      submittedAt,
      completedAt: normalizedTask.status === 'completed' ? new Date().toISOString() : null,
    });

    if (pollResult.status === 'completed') {
      return res.json({ ...normalizedTask, quota: getDailyUsage(req.user.id) });
    }

    if (pollResult.status === 'failed') {
      return res.status(502).json({ ...normalizedTask, quota: getDailyUsage(req.user.id) });
    }

    return res.json({ ...normalizedTask, quota: getDailyUsage(req.user.id) });
  } catch (err) {
    console.error('[Server Error]', err.raw || err);
    if (!acceptedProviderTaskId && quota?.date) {
      releaseDailyQuota(req.user.id, quota.date);
    }
    upsertTask({
      userId: req.user.id,
      clientTaskId,
      providerTaskId: null,
      sofaId: metadata.sofaId,
      sofaName: metadata.sofaName,
      status: 'failed',
      imageUrl: null,
      originalImage: metadata.originalImage || base64Image,
      configSnapshot: metadata.configSnapshot,
      message: '后端请求异常: ' + err.message,
      rawResponse: err.raw,
      chargedDate: acceptedProviderTaskId ? quota?.date : null,
      submittedAt,
    });
    return res.status(err.statusCode || 500).json({
      error: '后端请求异常: ' + err.message,
      raw: err.raw,
      quota: getDailyUsage(req.user.id),
    });
  }
});

app.get('/api/generate-tasks', requireAuth, (req, res) => {
  res.json({ tasks: listTasksForUser(req.user.id), quota: getDailyUsage(req.user.id) });
});

app.post('/api/query-task', requireAuth, async (req, res) => {
  const { taskId } = req.body;
  const providerConfig = getProviderConfig();

  if (!taskId) {
    return res.status(400).json({ error: '请提供 taskId' });
  }

  if (!providerConfig.apiKey) {
    return res.status(500).json({ error: '后端未配置图片生成 API Key，请先到管理员端配置' });
  }

  try {
    const raw = await queryBananaTask(taskId, providerConfig);
    const imageUrl = extractImageUrl(raw);
    const status = extractStatus(raw);
    const task = findTaskForUser({ userId: req.user.id, providerTaskId: taskId });
    if (task) {
      updateTaskForUser({
        userId: req.user.id,
        clientTaskId: task.clientTaskId,
        status: imageUrl ? 'completed' : status.toLowerCase() || 'processing',
        imageUrl,
        message: imageUrl ? '生成完成' : (extractErrorMessage(raw) || '任务仍在处理中'),
      });
    }
    return res.json({
      status: imageUrl ? 'completed' : status.toLowerCase() || 'processing',
      providerTaskId: taskId,
      imageUrl,
      message: imageUrl ? '生成完成' : (extractErrorMessage(raw) || '任务仍在处理中'),
      raw,
      quota: getDailyUsage(req.user.id),
    });
  } catch (err) {
    console.error('[Query Task Error]', err.raw || err);
    return res.status(err.statusCode || 500).json({ error: err.message, raw: err.raw });
  }
});

// ── 管理员路由 ─────────────────────────────────────────────────────
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  const user = findUserByUsername(username?.trim());

  if (!user || !verifyPassword(password || '', user)) {
    return res.status(401).json({ error: '管理员账户名或密码不正确' });
  }

  if (user.role !== 'admin') {
    return res.status(403).json({ error: '当前账号不是管理员账号' });
  }

  const session = createSession(user.id);
  setSessionCookie(res, session);
  return res.json({
    user: {
      id: user.id,
      username: user.username,
      displayName: user.display_name || user.username,
      role: user.role,
    },
  });
});

app.get('/api/admin/me', (req, res) => {
  const user = getUserBySession(getSessionId(req));
  if (!user || user.role !== 'admin') return res.json({ user: null });
  return res.json({ user });
});

app.post('/api/admin/logout', (req, res) => {
  deleteSession(getSessionId(req));
  clearSessionCookie(res);
  res.json({ ok: true });
});

app.get('/api/admin/overview', requireAdmin, (_req, res) => {
  res.json(getAdminOverview());
});

app.get('/api/admin/users', requireAdmin, (_req, res) => {
  res.json({ users: listUsersWithUsage() });
});

app.patch('/api/admin/users/:id/quota', requireAdmin, (req, res) => {
  const userId = Number(req.params.id);
  const targetUser = findUserById(userId);
  if (!targetUser) {
    return res.status(404).json({ error: '未找到该用户' });
  }

  const nextDailyLimit = req.body.dailyLimit === undefined ? undefined : Number(req.body.dailyLimit);
  const nextUsedCount = req.body.usedCount === undefined ? undefined : Number(req.body.usedCount);

  if (nextDailyLimit !== undefined && (!Number.isFinite(nextDailyLimit) || nextDailyLimit < 0)) {
    return res.status(400).json({ error: '每日额度必须是大于等于 0 的数字' });
  }

  if (nextUsedCount !== undefined && (!Number.isFinite(nextUsedCount) || nextUsedCount < 0)) {
    return res.status(400).json({ error: '今日已使用次数必须是大于等于 0 的数字' });
  }

  const result = updateUserQuota({
    userId,
    dailyLimit: nextDailyLimit,
    usedCount: nextUsedCount,
  });

  res.json({ ...result, users: listUsersWithUsage() });
});

app.get('/api/admin/tasks', requireAdmin, (req, res) => {
  const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 200));
  res.json({ tasks: listTasksForAdmin(limit) });
});

app.get('/api/admin/products', requireAdmin, (_req, res) => {
  res.json(catalogPayload());
});

app.post('/api/admin/products', requireAdmin, (req, res) => {
  try {
    const {
      modelId,
      name,
      structure = '直排沙发',
      seats = '三人位',
      material = '真皮',
      hasFunction = false,
      specText = '',
      seriesLabel = '',
      catalogImage,
      productImage,
    } = req.body;

    const normalizedModelId = safeSegment(modelId).toUpperCase();
    if (!normalizedModelId) {
      return res.status(400).json({ error: '请填写产品型号' });
    }

    if (!catalogImage?.dataUrl || !productImage?.dataUrl) {
      return res.status(400).json({ error: '请同时上传宣传图和白底图' });
    }

    const catalogImageUrl = saveDataUrlImage({
      dataUrl: catalogImage.dataUrl,
      filename: catalogImage.filename,
      modelId: normalizedModelId,
      kind: 'catalog',
    });
    const productImageUrl = saveDataUrlImage({
      dataUrl: productImage.dataUrl,
      filename: productImage.filename,
      modelId: normalizedModelId,
      kind: 'white',
    });

    const product = upsertProduct({
      modelId: normalizedModelId,
      name: name?.trim() || `演示品牌 ${normalizedModelId}`,
      catalogImageUrl,
      productImageUrl,
      specText,
      seriesLabel: seriesLabel?.trim() || '',
      year: seriesLabel?.trim() || '',
      structure,
      seats,
      material,
      hasFunction,
    });

    return res.json({ product, catalog: catalogPayload() });
  } catch (error) {
    console.error('[Admin Product Error]', error);
    return res.status(error.statusCode || 500).json({ error: error.message || '产品上传失败' });
  }
});

app.get('/api/admin/api-settings', requireAdmin, (_req, res) => {
  res.json({ settings: publicApiSettings() });
});

app.patch('/api/admin/api-settings', requireAdmin, (req, res) => {
  const incoming = req.body.settings || {};
  const knownSettings = listApiSettings();
  const payload = {};

  for (const setting of knownSettings) {
    if (!Object.prototype.hasOwnProperty.call(incoming, setting.key)) continue;
    const value = incoming[setting.key];
    if (setting.secret && String(value || '').trim() === '') continue;
    payload[setting.key] = String(value ?? '');
  }

  updateApiSettings(payload);
  const providerConfig = getProviderConfig();
  res.json({
    settings: publicApiSettings(),
    health: {
      apiUrl: providerConfig.apiUrl,
      queryUrl: providerConfig.queryUrl,
      hasApiKey: Boolean(providerConfig.apiKey),
      model: providerConfig.model,
      aspectRatio: providerConfig.aspectRatio,
      resolution: providerConfig.resolution,
      pollIntervalMs: providerConfig.pollIntervalMs,
      pollTimeoutMs: providerConfig.pollTimeoutMs,
    },
  });
});

// ── 健康检查 ─────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  const providerConfig = getProviderConfig();
  res.json({
    status: 'ok',
    provider: isQhProvider(providerConfig) ? 'qh-aigc' : 'banana2',
    apiUrl: providerConfig.apiUrl,
    queryUrl: providerConfig.queryUrl,
    hasApiKey: Boolean(providerConfig.apiKey),
    model: providerConfig.model,
    aspectRatio: providerConfig.aspectRatio,
    resolution: providerConfig.resolution,
    pollIntervalMs: providerConfig.pollIntervalMs,
    pollTimeoutMs: providerConfig.pollTimeoutMs,
  });
});

// ── 启动 ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  const providerConfig = getProviderConfig();
  console.log(`✅ Backend running at http://localhost:${PORT}`);
  console.log(`   API: ${providerConfig.apiUrl}`);
});
