import { execFileSync } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const DB_DIR = path.join(__dirname, 'data');
export const DB_PATH = process.env.SQLITE_DB_PATH || path.join(DB_DIR, 'app.db');
const SQLITE_BIN = process.env.SQLITE_BIN || '/usr/bin/sqlite3';
const PASSWORD_ITERATIONS = 150000;
const SESSION_DAYS = 7;
const DEFAULT_DAILY_LIMIT = 10;

const nowIso = () => new Date().toISOString();

const sqlString = (value) => {
  if (value === null || value === undefined) return 'NULL';
  return `'${String(value).replaceAll("'", "''")}'`;
};

const sqlNumber = (value) => {
  const number = Number(value);
  return Number.isFinite(number) ? String(number) : 'NULL';
};

const parseJson = (value, fallback = null) => {
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
};

const execSqlite = (args, input) => {
  try {
    return execFileSync(SQLITE_BIN, args, {
      input,
      encoding: 'utf8',
      maxBuffer: 1024 * 1024 * 30,
    });
  } catch (error) {
    const detail = error.stderr?.toString() || error.message;
    throw new Error(`SQLite 执行失败: ${detail}`);
  }
};

export const runSql = (sql) => execSqlite([DB_PATH], sql);

export const querySql = (sql) => {
  const output = execSqlite(['-json', DB_PATH, sql]).trim();
  return output ? JSON.parse(output) : [];
};

export const firstSql = (sql) => querySql(sql)[0] || null;

const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => {
  const hash = crypto.pbkdf2Sync(password, salt, PASSWORD_ITERATIONS, 32, 'sha256').toString('hex');
  return { hash, salt, iterations: PASSWORD_ITERATIONS };
};

export const verifyPassword = (password, user) => {
  if (!user?.password_hash || !user?.password_salt || !user?.password_iterations) return false;
  const inputHash = crypto
    .pbkdf2Sync(password, user.password_salt, Number(user.password_iterations), 32, 'sha256')
    .toString('hex');
  return crypto.timingSafeEqual(Buffer.from(inputHash, 'hex'), Buffer.from(user.password_hash, 'hex'));
};

const shanghaiDate = () => new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Shanghai',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
}).format(new Date());

const ensureColumn = (table, column, definition) => {
  const columns = querySql(`PRAGMA table_info(${table});`);
  if (!columns.some(item => item.name === column)) {
    runSql(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition};`);
  }
};

const createSchema = () => {
  fs.mkdirSync(DB_DIR, { recursive: true });
  runSql(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  password_iterations INTEGER NOT NULL,
  display_name TEXT,
  role TEXT NOT NULL DEFAULT 'store',
  daily_limit INTEGER NOT NULL DEFAULT ${DEFAULT_DAILY_LIMIT},
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS usage_daily (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  usage_date TEXT NOT NULL,
  used_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, usage_date),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS generation_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  client_task_id TEXT NOT NULL UNIQUE,
  provider_task_id TEXT,
  sofa_id TEXT,
  sofa_name TEXT,
  status TEXT NOT NULL,
  image_url TEXT,
  original_image TEXT,
  config_snapshot TEXT,
  message TEXT,
  raw_response TEXT,
  charged_date TEXT,
  submitted_at TEXT NOT NULL,
  completed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  model_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  catalog_image_url TEXT NOT NULL,
  product_image_url TEXT NOT NULL,
  spec_text TEXT,
  series_label TEXT,
  year TEXT,
  structure TEXT,
  seats TEXT,
  material TEXT,
  has_function INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS api_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  label TEXT NOT NULL,
  description TEXT,
  secret INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);
`);

  ensureColumn('users', 'display_name', 'TEXT');
  ensureColumn('users', 'role', "TEXT NOT NULL DEFAULT 'store'");
  runSql(`
UPDATE users
SET role = 'store', updated_at = ${sqlString(nowIso())}
WHERE role IS NULL OR role = '';
`);
};

const seedUser = ({ username, password, displayName, role = 'store', dailyLimit = DEFAULT_DAILY_LIMIT }) => {
  const timestamp = nowIso();
  const existing = firstSql(`SELECT id FROM users WHERE username = ${sqlString(username)} LIMIT 1;`);

  if (existing) {
    runSql(`
UPDATE users
SET
  display_name = COALESCE(display_name, ${sqlString(displayName)}),
  role = COALESCE(NULLIF(role, ''), ${sqlString(role)}),
  daily_limit = COALESCE(daily_limit, ${sqlNumber(dailyLimit)}),
  updated_at = ${sqlString(timestamp)}
WHERE id = ${sqlNumber(existing.id)};
`);
    return;
  }

  const passwordHash = hashPassword(password);
  runSql(`
INSERT INTO users (
  username,
  password_hash,
  password_salt,
  password_iterations,
  display_name,
  role,
  daily_limit,
  created_at,
  updated_at
) VALUES (
  ${sqlString(username)},
  ${sqlString(passwordHash.hash)},
  ${sqlString(passwordHash.salt)},
  ${sqlNumber(passwordHash.iterations)},
  ${sqlString(displayName)},
  ${sqlString(role)},
  ${sqlNumber(dailyLimit)},
  ${sqlString(timestamp)},
  ${sqlString(timestamp)}
);
`);
};

const seedApiSettings = () => {
  const timestamp = nowIso();
  const settings = [
    {
      key: 'banana_api_key',
      value: process.env.BANANA_API_KEY || '',
      label: '图片生成 API Key',
      description: '用于调用图片生成服务的 Bearer Token',
      secret: 1,
    },
    {
      key: 'banana_api_url',
      value: process.env.BANANA_API_URL || 'https://www.qh-aigc.com/api/v1/images/edits',
      label: '生图提交 URL',
      description: '图片生成/编辑提交任务地址',
      secret: 0,
    },
    {
      key: 'banana_query_url',
      value: process.env.BANANA_QUERY_URL || 'https://www.qh-aigc.com/api/v1/ai/result',
      label: '任务查询 URL',
      description: '根据 taskId 查询生成结果的地址',
      secret: 0,
    },
    {
      key: 'banana_model',
      value: process.env.BANANA_MODEL || '【限免】gpt-image-2',
      label: '生图模型',
      description: '千绘图片模型或工作流名称',
      secret: 0,
    },
    {
      key: 'banana_aspect_ratio',
      value: process.env.BANANA_ASPECT_RATIO || '16:9',
      label: '输出比例',
      description: '默认保持 16:9 横版效果图',
      secret: 0,
    },
    {
      key: 'banana_resolution',
      value: process.env.BANANA_RESOLUTION || '2K',
      label: '输出分辨率',
      description: '提交给图片接口的 resolution 参数',
      secret: 0,
    },
    {
      key: 'banana_webhook_url',
      value: process.env.BANANA_WEBHOOK_URL || '',
      label: 'Webhook URL',
      description: '可选，留空则由后端轮询查询结果',
      secret: 0,
    },
    {
      key: 'public_base_url',
      value: process.env.PUBLIC_BASE_URL || '',
      label: '公网图片访问地址',
      description: '用于让图片生成服务访问本地上传图片，如 https://你的域名 或 cloudflared/ngrok 地址',
      secret: 0,
    },
    {
      key: 'banana_poll_interval_ms',
      value: process.env.BANANA_POLL_INTERVAL_MS || '3000',
      label: '轮询间隔',
      description: '后端查询任务状态的间隔，单位毫秒',
      secret: 0,
    },
    {
      key: 'banana_poll_timeout_ms',
      value: process.env.BANANA_POLL_TIMEOUT_MS || '75000',
      label: '轮询超时',
      description: '后端等待单次任务完成的最长时间，单位毫秒',
      secret: 0,
    },
  ];

  for (const setting of settings) {
    runSql(`
INSERT INTO api_settings (key, value, label, description, secret, updated_at)
VALUES (
  ${sqlString(setting.key)},
  ${sqlString(setting.value)},
  ${sqlString(setting.label)},
  ${sqlString(setting.description)},
  ${sqlNumber(setting.secret)},
  ${sqlString(timestamp)}
)
ON CONFLICT(key) DO NOTHING;
`);
  }
};

export const initDb = () => {
  createSchema();
  seedUser({
    username: 'test',
    password: 'msm2026',
    displayName: 'Demo Store',
    role: 'store',
    dailyLimit: DEFAULT_DAILY_LIMIT,
  });
  seedUser({
    username: 'admin',
    password: 'msmadmin2026',
    displayName: '平台管理员',
    role: 'admin',
    dailyLimit: 999999,
  });
  seedApiSettings();
};

export const findUserByUsername = (username) => firstSql(`
SELECT * FROM users WHERE username = ${sqlString(username)} LIMIT 1;
`);

export const findUserById = (id) => firstSql(`
SELECT id, username, display_name, role, daily_limit, created_at, updated_at
FROM users
WHERE id = ${sqlNumber(id)}
LIMIT 1;
`);

export const createSession = (userId) => {
  const id = crypto.randomBytes(32).toString('hex');
  const createdAt = nowIso();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000).toISOString();

  runSql(`
INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at)
VALUES (${sqlString(id)}, ${sqlNumber(userId)}, ${sqlString(expiresAt)}, ${sqlString(createdAt)}, ${sqlString(createdAt)});
`);

  return { id, expiresAt, maxAgeSeconds: SESSION_DAYS * 24 * 60 * 60 };
};

export const deleteSession = (sessionId) => {
  if (!sessionId) return;
  runSql(`DELETE FROM sessions WHERE id = ${sqlString(sessionId)};`);
};

export const getUserBySession = (sessionId) => {
  if (!sessionId) return null;
  const session = firstSql(`
SELECT
  sessions.id AS session_id,
  sessions.user_id,
  sessions.expires_at,
  users.username,
  users.display_name,
  users.role,
  users.daily_limit
FROM sessions
JOIN users ON users.id = sessions.user_id
WHERE sessions.id = ${sqlString(sessionId)}
LIMIT 1;
`);

  if (!session) return null;
  if (new Date(session.expires_at).getTime() <= Date.now()) {
    deleteSession(sessionId);
    return null;
  }

  runSql(`UPDATE sessions SET last_seen_at = ${sqlString(nowIso())} WHERE id = ${sqlString(sessionId)};`);
  return {
    id: session.user_id,
    username: session.username,
    displayName: session.display_name || session.username,
    role: session.role || 'store',
    dailyLimit: session.daily_limit,
  };
};

export const getDailyUsage = (userId, usageDate = shanghaiDate()) => {
  const user = findUserById(userId);
  const row = firstSql(`
SELECT used_count FROM usage_daily
WHERE user_id = ${sqlNumber(userId)} AND usage_date = ${sqlString(usageDate)}
LIMIT 1;
`);
  const used = Number(row?.used_count || 0);
  const limit = Number(user?.daily_limit || DEFAULT_DAILY_LIMIT);
  return {
    date: usageDate,
    used,
    limit,
    remaining: Math.max(0, limit - used),
  };
};

export const reserveDailyQuota = (userId) => {
  const usage = getDailyUsage(userId);
  if (usage.remaining <= 0) {
    const error = new Error('今日 AI 搭配额度已用完，请明天再试');
    error.statusCode = 429;
    error.quota = usage;
    throw error;
  }

  const timestamp = nowIso();
  runSql(`
INSERT INTO usage_daily (user_id, usage_date, used_count, created_at, updated_at)
VALUES (${sqlNumber(userId)}, ${sqlString(usage.date)}, 1, ${sqlString(timestamp)}, ${sqlString(timestamp)})
ON CONFLICT(user_id, usage_date)
DO UPDATE SET used_count = used_count + 1, updated_at = ${sqlString(timestamp)};
`);

  return getDailyUsage(userId);
};

export const releaseDailyQuota = (userId, usageDate = shanghaiDate()) => {
  const timestamp = nowIso();
  runSql(`
UPDATE usage_daily
SET
  used_count = MAX(0, used_count - 1),
  updated_at = ${sqlString(timestamp)}
WHERE user_id = ${sqlNumber(userId)} AND usage_date = ${sqlString(usageDate)};
`);

  return getDailyUsage(userId, usageDate);
};

export const updateUserQuota = ({ userId, dailyLimit, usedCount, usageDate = shanghaiDate() }) => {
  const timestamp = nowIso();

  if (dailyLimit !== undefined && dailyLimit !== null) {
    runSql(`
UPDATE users
SET daily_limit = ${sqlNumber(Math.max(0, Number(dailyLimit)))}, updated_at = ${sqlString(timestamp)}
WHERE id = ${sqlNumber(userId)};
`);
  }

  if (usedCount !== undefined && usedCount !== null) {
    runSql(`
INSERT INTO usage_daily (user_id, usage_date, used_count, created_at, updated_at)
VALUES (
  ${sqlNumber(userId)},
  ${sqlString(usageDate)},
  ${sqlNumber(Math.max(0, Number(usedCount)))},
  ${sqlString(timestamp)},
  ${sqlString(timestamp)}
)
ON CONFLICT(user_id, usage_date)
DO UPDATE SET used_count = excluded.used_count, updated_at = ${sqlString(timestamp)};
`);
  }

  return {
    user: findUserById(userId),
    quota: getDailyUsage(userId, usageDate),
  };
};

export const upsertTask = ({
  userId,
  clientTaskId,
  providerTaskId,
  sofaId,
  sofaName,
  status,
  imageUrl,
  originalImage,
  configSnapshot,
  message,
  rawResponse,
  chargedDate,
  submittedAt,
  completedAt,
}) => {
  const timestamp = nowIso();
  const configJson = configSnapshot ? JSON.stringify(configSnapshot) : null;
  const rawJson = rawResponse ? JSON.stringify(rawResponse) : null;
  runSql(`
INSERT INTO generation_tasks (
  user_id,
  client_task_id,
  provider_task_id,
  sofa_id,
  sofa_name,
  status,
  image_url,
  original_image,
  config_snapshot,
  message,
  raw_response,
  charged_date,
  submitted_at,
  completed_at,
  created_at,
  updated_at
) VALUES (
  ${sqlNumber(userId)},
  ${sqlString(clientTaskId)},
  ${sqlString(providerTaskId)},
  ${sqlString(sofaId)},
  ${sqlString(sofaName)},
  ${sqlString(status)},
  ${sqlString(imageUrl)},
  ${sqlString(originalImage)},
  ${sqlString(configJson)},
  ${sqlString(message)},
  ${sqlString(rawJson)},
  ${sqlString(chargedDate)},
  ${sqlString(submittedAt || timestamp)},
  ${sqlString(completedAt)},
  ${sqlString(timestamp)},
  ${sqlString(timestamp)}
)
ON CONFLICT(client_task_id)
DO UPDATE SET
  provider_task_id = excluded.provider_task_id,
  sofa_id = excluded.sofa_id,
  sofa_name = excluded.sofa_name,
  status = excluded.status,
  image_url = excluded.image_url,
  original_image = COALESCE(excluded.original_image, generation_tasks.original_image),
  config_snapshot = COALESCE(excluded.config_snapshot, generation_tasks.config_snapshot),
  message = excluded.message,
  raw_response = excluded.raw_response,
  charged_date = excluded.charged_date,
  completed_at = excluded.completed_at,
  updated_at = ${sqlString(timestamp)};
`);
};

const normalizeTask = (row) => ({
  id: row.client_task_id,
  status: row.status,
  imageUrl: row.image_url || null,
  originalImage: row.original_image || null,
  sofaId: row.sofa_id || null,
  sofaName: row.sofa_name || '未命名沙发',
  configSnapshot: parseJson(row.config_snapshot),
  rawResponse: parseJson(row.raw_response),
  clientTaskId: row.client_task_id,
  providerTaskId: row.provider_task_id || null,
  message: row.message || '',
  chargedDate: row.charged_date || null,
  submittedAt: row.submitted_at || row.created_at,
  completedAt: row.completed_at || null,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

const normalizeAdminTask = (row) => ({
  ...normalizeTask(row),
  userId: row.user_id,
  username: row.username,
  displayName: row.display_name || row.username,
  dailyLimit: Number(row.daily_limit || 0),
  quotaOwner: row.charged_date ? `${row.charged_date} 用户额度` : '未记录扣费日期',
});

export const listTasksForUser = (userId) => querySql(`
SELECT * FROM generation_tasks
WHERE user_id = ${sqlNumber(userId)}
ORDER BY created_at DESC
LIMIT 30;
`).map(normalizeTask);

export const findTaskForUser = ({ userId, clientTaskId, providerTaskId }) => {
  const where = clientTaskId
    ? `client_task_id = ${sqlString(clientTaskId)}`
    : `provider_task_id = ${sqlString(providerTaskId)}`;
  const row = firstSql(`
SELECT * FROM generation_tasks
WHERE user_id = ${sqlNumber(userId)} AND ${where}
LIMIT 1;
`);
  return row ? normalizeTask(row) : null;
};

export const updateTaskForUser = ({ userId, clientTaskId, status, imageUrl, message }) => {
  const timestamp = nowIso();
  runSql(`
UPDATE generation_tasks
SET
  status = COALESCE(${sqlString(status)}, status),
  image_url = COALESCE(${sqlString(imageUrl)}, image_url),
  message = COALESCE(${sqlString(message)}, message),
  completed_at = CASE WHEN ${sqlString(status)} = 'completed' THEN ${sqlString(timestamp)} ELSE completed_at END,
  updated_at = ${sqlString(timestamp)}
WHERE user_id = ${sqlNumber(userId)} AND client_task_id = ${sqlString(clientTaskId)};
`);
  return findTaskForUser({ userId, clientTaskId });
};

export const deleteTaskForUser = ({ userId, clientTaskId }) => {
  runSql(`
DELETE FROM generation_tasks
WHERE user_id = ${sqlNumber(userId)} AND client_task_id = ${sqlString(clientTaskId)};
`);
};

export const listUsersWithUsage = (usageDate = shanghaiDate()) => querySql(`
SELECT
  users.id,
  users.username,
  users.display_name,
  users.role,
  users.daily_limit,
  users.created_at,
  users.updated_at,
  COALESCE(usage_daily.used_count, 0) AS today_used_count,
  (
    SELECT COUNT(*) FROM generation_tasks
    WHERE generation_tasks.user_id = users.id
  ) AS total_task_count,
  (
    SELECT MAX(created_at) FROM generation_tasks
    WHERE generation_tasks.user_id = users.id
  ) AS latest_generation_at
FROM users
LEFT JOIN usage_daily
  ON usage_daily.user_id = users.id
  AND usage_daily.usage_date = ${sqlString(usageDate)}
ORDER BY users.role ASC, users.created_at ASC;
`).map(row => ({
  id: row.id,
  username: row.username,
  displayName: row.display_name || row.username,
  role: row.role || 'store',
  dailyLimit: Number(row.daily_limit || DEFAULT_DAILY_LIMIT),
  todayUsedCount: Number(row.today_used_count || 0),
  todayRemaining: Math.max(0, Number(row.daily_limit || DEFAULT_DAILY_LIMIT) - Number(row.today_used_count || 0)),
  totalTaskCount: Number(row.total_task_count || 0),
  latestGenerationAt: row.latest_generation_at || null,
  usageDate,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
}));

export const listTasksForAdmin = (limit = 200) => querySql(`
SELECT
  generation_tasks.*,
  users.username,
  users.display_name,
  users.daily_limit
FROM generation_tasks
JOIN users ON users.id = generation_tasks.user_id
ORDER BY generation_tasks.created_at DESC
LIMIT ${sqlNumber(limit)};
`).map(normalizeAdminTask);

const normalizeProduct = (row) => ({
  id: row.model_id,
  name: row.name,
  image: row.catalog_image_url,
  productImage: row.product_image_url,
  year: row.series_label || row.year || '管理员新增',
  seriesLabel: row.series_label || '',
  structure: row.structure || '直排沙发',
  seats: row.seats || '三人位',
  structureTags: [
    row.structure || '直排沙发',
    Number(row.has_function) ? '功能沙发' : null,
  ].filter(Boolean),
  material: row.material || '真皮',
  hasFunction: Boolean(Number(row.has_function)),
  specText: row.spec_text || '',
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

export const listProducts = () => querySql(`
SELECT * FROM products
ORDER BY created_at DESC, model_id ASC;
`).map(normalizeProduct);

export const upsertProduct = ({
  modelId,
  name,
  catalogImageUrl,
  productImageUrl,
  specText,
  seriesLabel,
  year,
  structure,
  seats,
  material,
  hasFunction,
}) => {
  const timestamp = nowIso();
  runSql(`
INSERT INTO products (
  model_id,
  name,
  catalog_image_url,
  product_image_url,
  spec_text,
  series_label,
  year,
  structure,
  seats,
  material,
  has_function,
  created_at,
  updated_at
) VALUES (
  ${sqlString(modelId)},
  ${sqlString(name)},
  ${sqlString(catalogImageUrl)},
  ${sqlString(productImageUrl)},
  ${sqlString(specText)},
  ${sqlString(seriesLabel)},
  ${sqlString(year || seriesLabel)},
  ${sqlString(structure)},
  ${sqlString(seats)},
  ${sqlString(material)},
  ${sqlNumber(hasFunction ? 1 : 0)},
  ${sqlString(timestamp)},
  ${sqlString(timestamp)}
)
ON CONFLICT(model_id)
DO UPDATE SET
  name = excluded.name,
  catalog_image_url = excluded.catalog_image_url,
  product_image_url = excluded.product_image_url,
  spec_text = excluded.spec_text,
  series_label = excluded.series_label,
  year = excluded.year,
  structure = excluded.structure,
  seats = excluded.seats,
  material = excluded.material,
  has_function = excluded.has_function,
  updated_at = ${sqlString(timestamp)};
`);

  return listProducts().find(product => product.id === modelId) || null;
};

export const listApiSettings = () => querySql(`
SELECT key, value, label, description, secret, updated_at
FROM api_settings
ORDER BY rowid ASC;
`).map(row => ({
  key: row.key,
  value: row.value || '',
  label: row.label,
  description: row.description || '',
  secret: Boolean(Number(row.secret)),
  updatedAt: row.updated_at,
}));

export const getApiSettingsMap = () => Object.fromEntries(
  listApiSettings().map(setting => [setting.key, setting.value])
);

export const updateApiSettings = (settings) => {
  const timestamp = nowIso();
  const allowedKeys = new Set(listApiSettings().map(setting => setting.key));

  for (const [key, value] of Object.entries(settings || {})) {
    if (!allowedKeys.has(key)) continue;
    runSql(`
UPDATE api_settings
SET value = ${sqlString(value)}, updated_at = ${sqlString(timestamp)}
WHERE key = ${sqlString(key)};
`);
  }

  return listApiSettings();
};

export const getAdminOverview = () => {
  const users = listUsersWithUsage();
  const tasks = listTasksForAdmin(50);
  return {
    users,
    tasks,
    products: listProducts(),
    usageDate: shanghaiDate(),
    totals: {
      storeUsers: users.filter(user => user.role !== 'admin').length,
      tasks: tasks.length,
      completedTasks: tasks.filter(task => task.status === 'completed').length,
      processingTasks: tasks.filter(task => task.status === 'processing').length,
    },
  };
};
