function makePhoneCall(phoneNumber) {
  if (!phoneNumber) {
    wx.showToast({
      title: '暂无联系电话',
      icon: 'none'
    });
    return;
  }

  wx.makePhoneCall({
    phoneNumber
  });
}

function copyText(text, label) {
  if (!text) {
    wx.showToast({
      title: '暂无可复制内容',
      icon: 'none'
    });
    return;
  }

  wx.setClipboardData({
    data: text,
    success() {
      wx.showToast({
        title: `${label || '内容'}已复制`,
        icon: 'none'
      });
    }
  });
}

function openLocation(location) {
  if (!location || typeof location.latitude !== 'number' || typeof location.longitude !== 'number') {
    wx.showToast({
      title: '请补充地图经纬度',
      icon: 'none'
    });
    return;
  }

  wx.openLocation({
    latitude: location.latitude,
    longitude: location.longitude,
    name: location.name,
    address: location.address,
    scale: 16
  });
}

function switchTab(url) {
  if (!url) {
    return;
  }

  wx.switchTab({
    url
  });
}

function navigateTo(url) {
  if (!url) {
    return;
  }

  wx.navigateTo({
    url
  });
}

module.exports = {
  makePhoneCall,
  copyText,
  openLocation,
  switchTab,
  navigateTo
};
