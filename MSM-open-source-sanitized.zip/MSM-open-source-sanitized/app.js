const { brandInfo } = require('./data/brand');
const { contactInfo } = require('./data/contact');

const DEFAULT_SHARE_IMAGE = '/assets/images/display/showroom/showroom.jpg';
const WEBVIEW_ROUTE = 'pages/webview/index';

function serializeQuery(options) {
  return Object.keys(options || {})
    .filter((key) => options[key] !== undefined && options[key] !== null && options[key] !== '')
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(options[key])}`)
    .join('&');
}

function getShareMeta(pageInstance) {
  const route = pageInstance.route || 'pages/home/index';
  const options = pageInstance.__shareOptions || {};
  const query = serializeQuery(options);
  const path = `/${route}${query ? `?${query}` : ''}`;
  const data = pageInstance.data || {};
  const product = data.product;
  const event = data.event;

  if (route === 'pages/home/index') {
    return {
      title: '家具图册示例｜首页',
      imageUrl: DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  if (route === 'pages/products/index') {
    return {
      title: '家具图册示例｜产品图册',
      imageUrl: DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  if (route === 'pages/events/index') {
    return {
      title: '家具图册示例｜活动信息',
      imageUrl: DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  if (route === 'pages/contact/index') {
    return {
      title: '示例家具｜联系我们',
      imageUrl: DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  if (product) {
    return {
      title: `${product.name}｜家具图册示例`,
      imageUrl: product.cover || (product.images && product.images[0]) || DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  if (event) {
    return {
      title: `${event.title}｜示例家具`,
      imageUrl: event.cover || DEFAULT_SHARE_IMAGE,
      path,
      query
    };
  }

  return {
    title: '家具图册示例',
    imageUrl: DEFAULT_SHARE_IMAGE,
    path,
    query
  };
}

function syncShareMenu(pageInstance) {
  if (typeof wx.showShareMenu !== 'function') {
    return;
  }

  if (pageInstance.route === WEBVIEW_ROUTE) {
    if (typeof wx.hideShareMenu === 'function') {
      wx.hideShareMenu();
    }
    return;
  }

  wx.showShareMenu({
    withShareTicket: true,
    menus: ['shareAppMessage', 'shareTimeline']
  });
}

const nativePage = Page;

Page = function wrapPage(pageOptions) {
  const options = pageOptions || {};
  const originalOnLoad = options.onLoad;
  const originalOnShow = options.onShow;

  options.onLoad = function patchedOnLoad(loadOptions) {
    this.__shareOptions = loadOptions || {};
    syncShareMenu(this);

    if (typeof originalOnLoad === 'function') {
      return originalOnLoad.call(this, loadOptions);
    }
  };

  options.onShow = function patchedOnShow() {
    syncShareMenu(this);

    if (typeof originalOnShow === 'function') {
      return originalOnShow.call(this);
    }
  };

  if (typeof options.onShareAppMessage !== 'function') {
    options.onShareAppMessage = function defaultShareAppMessage() {
      const meta = getShareMeta(this);

      return {
        title: meta.title,
        path: meta.path,
        imageUrl: meta.imageUrl
      };
    };
  }

  if (typeof options.onShareTimeline !== 'function') {
    options.onShareTimeline = function defaultShareTimeline() {
      const meta = getShareMeta(this);

      return {
        title: meta.title,
        query: meta.query,
        imageUrl: meta.imageUrl
      };
    };
  }

  return nativePage(options);
};

App({
  globalData: {
    brandInfo,
    contactInfo,
    placeholderImage: DEFAULT_SHARE_IMAGE,
    defaultPhone: contactInfo.phones[0].number
  }
});
