const { makePhoneCall, switchTab } = require('../../utils/actions');

Component({
  properties: {
    phone: {
      type: String,
      value: ''
    },
    showHome: {
      type: Boolean,
      value: true
    },
    homeText: {
      type: String,
      value: '返回主页'
    },
    phoneText: {
      type: String,
      value: '电话咨询'
    }
  },
  methods: {
    handleHome() {
      switchTab('/pages/home/index');
    },
    handlePhone() {
      makePhoneCall(this.data.phone);
    }
  }
});
