Component({
  properties: {
    product: {
      type: Object,
      value: {}
    },
    mode: {
      type: String,
      value: 'default'
    }
  },
  data: {
    coverFailed: false,
    visibleTags: []
  },
  observers: {
    product(product) {
      this.setData({
        coverFailed: false,
        visibleTags: (product && product.cardTags ? product.cardTags : []).slice(0, 2)
      });
    }
  },
  methods: {
    handleTap() {
      if (!this.data.product || !this.data.product.id) {
        return;
      }

      this.triggerEvent('tapcard', {
        id: this.data.product.id
      });
    },
    handleImageError() {
      this.setData({
        coverFailed: true
      });
    }
  }
});
