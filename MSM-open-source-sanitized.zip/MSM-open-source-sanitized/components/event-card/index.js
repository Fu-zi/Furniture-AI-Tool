Component({
  properties: {
    event: {
      type: Object,
      value: {}
    }
  },
  data: {
    coverFailed: false
  },
  observers: {
    event() {
      this.setData({
        coverFailed: false
      });
    }
  },
  methods: {
    handleTap() {
      if (!this.data.event || !this.data.event.id) {
        return;
      }

      this.triggerEvent('tapcard', {
        id: this.data.event.id
      });
    },
    handleImageError() {
      this.setData({
        coverFailed: true
      });
    }
  }
});
