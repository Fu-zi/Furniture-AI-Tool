const { contactInfo } = require('./contact');

const brandInfo = {
  appName: '家具图册示例',
  brandName: 'Demo Furniture',
  shopName: 'Demo Furniture',
  slogan: '开源图册模板',
  subSlogan: '用于展示小程序图册结构',
  showroomImage: '/assets/images/display/showroom/brand.jpg',
  targetUsers: ['家装用户', '经销商'],
  homeHeroTitle: '家具图册示例项目',
  homeHeroSubtitle: '一个可复用的原生微信小程序模板',
  primaryPhone: contactInfo.phones[0].number
};

const brandHeroBanner = {
  id: 'brand',
  image: '/assets/images/display/showroom/showroom.jpg',
  eyebrow: 'DEMO FURNITURE',
  title: '开源图册模板',
  description: '✔ 本地 mock 数据 ✔ 原生小程序 ✔ 可自由替换内容'
};

const brandExpressionBanner = {
  id: 'brand-expression',
  image: '/assets/images/display/showroom/brand.jpg',
  eyebrow: 'DEMO FURNITURE',
  title: '适合家具与产品图册展示',
  description: '保留首页、产品列表、详情、活动和联系页面结构，方便开发者二次开发。'
};

const brandStory = {
  title: '项目介绍',
  description: '这是一个脱敏后的微信小程序图册示例，使用原生小程序语法和本地 mock 数据。示例内容用于展示页面结构、组件拆分和视觉风格，不包含真实品牌、产品、地址或联系方式。'
};

const homeHighlights = [
  { title: '原生小程序结构', description: '包含 app、pages、components、data 与分包示例。' },
  { title: '本地 mock 数据', description: '产品、活动和联系方式均可直接替换为真实业务数据。' },
  { title: '图册展示体验', description: '支持搜索、筛选、详情轮播和电话咨询等常见功能。' }
];

module.exports = {
  brandInfo,
  brandHeroBanner,
  brandExpressionBanner,
  brandStory,
  homeHighlights
};
