const address = '示例城市示例区示例路 100 号';

const contactInfo = {
  companyName: '示例家具有限公司',
  contacts: ['示例联系人'],
  phones: [
    { label: '客服', number: '00000000000' },
    { label: '门店', number: '00000000001' }
  ],
  wechat: 'demo_wechat_id',
  address,
  businessHours: '9:00 - 18:00',
  coordinateText: '23.1291, 113.2644',
  plusCode: 'Demo District, Demo City, China',
  location: {
    name: '示例家具展厅',
    address,
    latitude: 23.1291,
    longitude: 113.2644,
    isMockCoordinate: true
  }
};

module.exports = { contactInfo };
