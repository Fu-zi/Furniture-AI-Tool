const events = [
  {
    id: 'event-demo-launch',
    title: '示例新品发布',
    cover: '/assets/images/display/showroom/showroom.jpg',
    time: '2026.01.01 - 2026.01.03',
    summary: '用于演示活动列表、活动详情和咨询入口的 mock 数据。',
    status: '示例',
    tone: 'planned',
    articleUrl: '',
    webUrl: '',
    nativeDetailEnabled: true,
    detailSections: [
      { title: '活动说明', content: '这里是脱敏后的活动详情内容，可替换为真实活动介绍。' },
      { title: '适用场景', content: '适合作为家具、家居或产品图册类小程序的活动页示例。' }
    ]
  },
  {
    id: 'event-demo-booking',
    title: '示例预约咨询',
    cover: '/assets/images/display/showroom/brand.jpg',
    time: '长期有效',
    summary: '用于演示预约到店、电话咨询和活动详情页结构。',
    status: '预约中',
    tone: 'active',
    articleUrl: '',
    webUrl: '',
    nativeDetailEnabled: true,
    detailSections: [
      { title: '预约方式', content: '可替换为你的预约流程、门店说明或客服提示。' }
    ]
  }
];

const eventMap = {};
events.forEach((item) => {
  eventMap[item.id] = item;
});

module.exports = { events, eventMap };
