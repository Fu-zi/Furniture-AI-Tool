Page({
  data: {
    title: '活动文章',
    url: ''
  },

  onLoad(options) {
    const title = decodeURIComponent(options.title || '活动文章');
    const url = decodeURIComponent(options.url || '');

    wx.setNavigationBarTitle({
      title
    });

    this.setData({
      title,
      url
    });
  }
});
