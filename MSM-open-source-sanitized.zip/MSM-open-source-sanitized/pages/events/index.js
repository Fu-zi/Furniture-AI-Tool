const { events, eventMap } = require('../../data/events');
const { contactInfo } = require('../../data/contact');
const { navigateTo } = require('../../utils/actions');

Page({
  data: {
    events,
    primaryPhone: contactInfo.phones[0].number
  },

  handleEventTap(event) {
    const eventInfo = eventMap[event.detail.id];

    if (!eventInfo) {
      return;
    }

    this.openEvent(eventInfo);
  },

  openEvent(eventInfo) {
    if (eventInfo.articleUrl) {
      if (typeof wx.openOfficialAccountArticle === 'function') {
        wx.openOfficialAccountArticle({
          articleUrl: eventInfo.articleUrl,
          fail: () => {
            this.openFallback(eventInfo);
          }
        });
        return;
      }

      this.openFallback(eventInfo);
      return;
    }

    if (eventInfo.nativeDetailEnabled) {
      navigateTo(`/pages/event-detail/index?id=${eventInfo.id}`);
      return;
    }

    this.openFallback(eventInfo);
  },

  openFallback(eventInfo) {
    if (eventInfo.webUrl) {
      navigateTo(`/pages/webview/index?title=${encodeURIComponent(eventInfo.title)}&url=${encodeURIComponent(eventInfo.webUrl)}`);
      return;
    }

    if (eventInfo.nativeDetailEnabled) {
      navigateTo(`/pages/event-detail/index?id=${eventInfo.id}`);
      return;
    }

    wx.showToast({
      title: '活动详情待补充',
      icon: 'none'
    });
  }
});
