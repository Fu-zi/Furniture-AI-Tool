const { brandInfo, brandHeroBanner, brandExpressionBanner, brandStory, homeHighlights } = require('../../data/brand');
const { hotProducts, newProducts, productMap } = require('../../data/products');
const { events } = require('../../data/events');
const { contactInfo } = require('../../data/contact');
const { makePhoneCall, switchTab, navigateTo, copyText } = require('../../utils/actions');

function shuffle(items) {
  const result = items.slice();

  for (let index = result.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    const current = result[index];
    result[index] = result[randomIndex];
    result[randomIndex] = current;
  }

  return result;
}

Page({
  data: {
    brandInfo,
    heroBanners: [],
    brandStory,
    homeHighlights,
    hotProducts: hotProducts.slice(0, 4),
    latestEvents: events.slice(0, 2),
    contactInfo,
    currentBanner: 0,
    showroomError: false
  },

  onShow() {
    this.refreshHeroBanners();
  },

  refreshHeroBanners() {
    const randomProducts = shuffle(newProducts).slice(0, 3).map((item) => ({
      id: item.id,
      image: item.cover,
      eyebrow: item.annualCategory,
      title: item.heroTitle,
      description: item.heroDescription,
      detailPath: item.detailPath
    }));

    this.setData({
      heroBanners: [brandHeroBanner].concat(randomProducts).concat([brandExpressionBanner]),
      currentBanner: 0
    });
  },

  onBannerChange(event) {
    this.setData({
      currentBanner: event.detail.current
    });
  },

  handleBannerTap(event) {
    const { path } = event.currentTarget.dataset;

    if (!path) {
      return;
    }

    navigateTo(path);
  },

  handleShowroomError() {
    this.setData({
      showroomError: true
    });
  },

  goProducts() {
    switchTab('/pages/products/index');
  },

  goEvents() {
    switchTab('/pages/events/index');
  },

  goContact() {
    switchTab('/pages/contact/index');
  },

  goProductDetail(event) {
    const product = productMap[event.detail.id];

    if (!product || !product.detailPath) {
      return;
    }

    navigateTo(product.detailPath);
  },

  callPrimary() {
    makePhoneCall(contactInfo.phones[0].number);
  },

  copyWechat() {
    copyText(contactInfo.wechat, '微信号');
  }
});
