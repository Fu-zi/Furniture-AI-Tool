const { products, productMap, structureOptions, annualOptions } = require('../../data/products');
const { navigateTo } = require('../../utils/actions');
const CATALOG_VIEW_URL = 'https://example.com/catalog-demo';

function getProductSortKey(id) {
  const normalized = String(id || '').toUpperCase();
  const matched = normalized.match(/^([A-Z]+)?(\d+)([A-Z]+)?$/);

  if (!matched) {
    return {
      prefix: normalized,
      number: Number.MAX_SAFE_INTEGER,
      suffix: ''
    };
  }

  return {
    prefix: matched[1] || '',
    number: Number(matched[2] || 0),
    suffix: matched[3] || ''
  };
}

function compareProducts(left, right) {
  const leftKey = getProductSortKey(left.id);
  const rightKey = getProductSortKey(right.id);

  if (leftKey.prefix !== rightKey.prefix) {
    return leftKey.prefix.localeCompare(rightKey.prefix);
  }

  if (leftKey.number !== rightKey.number) {
    return leftKey.number - rightKey.number;
  }

  return leftKey.suffix.localeCompare(rightKey.suffix);
}

Page({
  data: {
    keyword: '',
    structureOptions,
    annualOptions,
    activeStructure: '全部',
    activeAnnual: '全部',
    allProducts: products,
    filteredProducts: products,
    resultCount: products.length,
    showAnnualFilter: annualOptions.filter((item) => item !== '全部').length > 1,
    currentCollectionLabel: annualOptions.find((item) => item !== '全部') || ''
  },

  onLoad() {
    this.applyFilters();
  },

  handleKeywordInput(event) {
    this.setData({
      keyword: event.detail.value
    });
    this.applyFilters();
  },

  clearKeyword() {
    this.setData({
      keyword: ''
    });
    this.applyFilters();
  },

  selectStructure(event) {
    this.setData({
      activeStructure: event.currentTarget.dataset.value
    });
    this.applyFilters();
  },

  selectAnnual(event) {
    this.setData({
      activeAnnual: event.currentTarget.dataset.value
    });
    this.applyFilters();
  },

  applyFilters() {
    const keyword = this.data.keyword.trim().toLowerCase();
    const filteredProducts = this.data.allProducts.filter((item) => {
      const matchKeyword = !keyword || item.searchKeywords.toLowerCase().indexOf(keyword) > -1;
      const matchStructure = this.data.activeStructure === '全部' || item.structureCategory.indexOf(this.data.activeStructure) > -1;
      const matchAnnual = this.data.activeAnnual === '全部' || item.annualCategory === this.data.activeAnnual;

      return matchKeyword && matchStructure && matchAnnual;
    }).sort(compareProducts);

    this.setData({
      filteredProducts,
      resultCount: filteredProducts.length
    });
  },

  goDetail(event) {
    const product = productMap[event.detail.id];

    if (!product || !product.detailPath) {
      return;
    }

    navigateTo(product.detailPath);
  },

  handleDownloadCatalog() {
    wx.showModal({
      title: '高清图册',
      content: `下载功能正在升级维护中，暂时无法在小程序内使用。\n请复制以下链接打开文档：\n${CATALOG_VIEW_URL}`,
      confirmText: '复制链接',
      cancelText: '关闭',
      success: ({ confirm }) => {
        if (!confirm) {
          return;
        }

        wx.setClipboardData({
          data: CATALOG_VIEW_URL
        });
      }
    });
  }
});
