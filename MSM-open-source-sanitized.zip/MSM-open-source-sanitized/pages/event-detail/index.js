const { eventMap } = require('../../data/events');
const { contactInfo } = require('../../data/contact');
const { makePhoneCall, switchTab } = require('../../utils/actions');

Page({
  data: {
    event: null
  },

  onLoad(options) {
    const event = eventMap[options.id];

    if (!event) {
      wx.showToast({
        title: '活动不存在',
        icon: 'none'
      });
      return;
    }

    wx.setNavigationBarTitle({
      title: event.title
    });

    this.setData({
      event
    });
  },

  callPhone() {
    makePhoneCall(contactInfo.phones[0].number);
  },

  goEvents() {
    switchTab('/pages/events/index');
  }
});
