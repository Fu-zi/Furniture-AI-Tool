const { brandInfo } = require('../../data/brand');
const { contactInfo } = require('../../data/contact');
const { makePhoneCall, copyText, openLocation } = require('../../utils/actions');

Page({
  data: {
    brandInfo,
    contactInfo,
    contactsText: contactInfo.contacts.join(' / '),
    markers: [
      {
        id: 1,
        latitude: contactInfo.location.latitude,
        longitude: contactInfo.location.longitude,
        iconPath: '/assets/images/map/location-marker.png',
        width: 40,
        height: 40,
        callout: {
          content: '示例家具',
          color: '#3e342c',
          fontSize: 12,
          borderRadius: 12,
          padding: 8,
          bgColor: '#fffaf5',
          display: 'ALWAYS'
        }
      }
    ]
  },

  callPhone(event) {
    makePhoneCall(event.currentTarget.dataset.phone);
  },

  copyAddress() {
    copyText(contactInfo.address, '地址');
  },

  copyWechat() {
    copyText(contactInfo.wechat, '微信号');
  },

  openMap() {
    openLocation(contactInfo.location);
  },

  handleMarkerTap() {
    this.openMap();
  },

  handleMapTap() {
    this.openMap();
  }
});
