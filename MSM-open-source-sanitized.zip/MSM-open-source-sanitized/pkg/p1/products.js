const products = [
  {
    "id": "DEMO-01",
    "name": "DEMO-01",
    "displayName": "云岚三人位",
    "cover": "/pkg/p1/assets/products/DEMO-01/cover.jpg",
    "structureCategory": [
      "直排沙发",
      "三人位",
      "布艺沙发"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 2.8 米 / 坐深 0.98 米",
    "material": "科技布 / 高回弹海绵",
    "configuration": "三人位组合",
    "intro": "云岚三人位是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "云岚三人位",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 2.8 米 / 坐深 0.98 米 / 科技布 / 高回弹海绵",
    "cardTags": [
      "直排沙发",
      "三人位",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-01|云岚三人位|科技布 / 高回弹海绵|三人位组合|2026 示例系列|直排沙发|三人位|布艺沙发",
    "detailPath": "/pkg/p1/index?id=DEMO-01",
    "images": [
      "/pkg/p1/assets/products/DEMO-01/cover.jpg",
      "/pkg/p1/assets/products/DEMO-01/side.jpg",
      "/pkg/p1/assets/products/DEMO-01/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-01/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-01/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 2.8 米 / 坐深 0.98 米"
      },
      {
        "label": "材质",
        "value": "科技布 / 高回弹海绵"
      },
      {
        "label": "组合",
        "value": "三人位组合"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-01/detail.jpg"
    ]
  },
  {
    "id": "DEMO-02",
    "name": "DEMO-02",
    "displayName": "木屿转角沙发",
    "cover": "/pkg/p1/assets/products/DEMO-02/cover.jpg",
    "structureCategory": [
      "L型沙发",
      "转角沙发",
      "四人位"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 3.4 米 / 贵妃位 1.75 米",
    "material": "仿皮面料 / 实木框架",
    "configuration": "双人位 + 贵妃位",
    "intro": "木屿转角沙发是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "木屿转角沙发",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 3.4 米 / 贵妃位 1.75 米 / 仿皮面料 / 实木框架",
    "cardTags": [
      "L型沙发",
      "转角沙发",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-02|木屿转角沙发|仿皮面料 / 实木框架|双人位 + 贵妃位|2026 示例系列|L型沙发|转角沙发|四人位",
    "detailPath": "/pkg/p1/index?id=DEMO-02",
    "images": [
      "/pkg/p1/assets/products/DEMO-02/cover.jpg",
      "/pkg/p1/assets/products/DEMO-02/side.jpg",
      "/pkg/p1/assets/products/DEMO-02/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-02/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-02/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 3.4 米 / 贵妃位 1.75 米"
      },
      {
        "label": "材质",
        "value": "仿皮面料 / 实木框架"
      },
      {
        "label": "组合",
        "value": "双人位 + 贵妃位"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-02/detail.jpg"
    ]
  },
  {
    "id": "DEMO-03",
    "name": "DEMO-03",
    "displayName": "序光双人位",
    "cover": "/pkg/p1/assets/products/DEMO-03/cover.jpg",
    "structureCategory": [
      "直排沙发",
      "双人位",
      "皮艺沙发"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 2.1 米 / 坐深 0.95 米",
    "material": "仿真皮 / 羽绒靠包",
    "configuration": "双人位组合",
    "intro": "序光双人位是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "序光双人位",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 2.1 米 / 坐深 0.95 米 / 仿真皮 / 羽绒靠包",
    "cardTags": [
      "直排沙发",
      "双人位",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-03|序光双人位|仿真皮 / 羽绒靠包|双人位组合|2026 示例系列|直排沙发|双人位|皮艺沙发",
    "detailPath": "/pkg/p1/index?id=DEMO-03",
    "images": [
      "/pkg/p1/assets/products/DEMO-03/cover.jpg",
      "/pkg/p1/assets/products/DEMO-03/side.jpg",
      "/pkg/p1/assets/products/DEMO-03/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-03/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-03/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 2.1 米 / 坐深 0.95 米"
      },
      {
        "label": "材质",
        "value": "仿真皮 / 羽绒靠包"
      },
      {
        "label": "组合",
        "value": "双人位组合"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-03/detail.jpg"
    ]
  },
  {
    "id": "DEMO-04",
    "name": "DEMO-04",
    "displayName": "栖木功能沙发",
    "cover": "/pkg/p1/assets/products/DEMO-04/cover.jpg",
    "structureCategory": [
      "直排沙发",
      "功能沙发",
      "三人位"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 3.0 米 / 坐深 1.02 米",
    "material": "仿皮面料 / 电动功能位",
    "configuration": "左单 + 无单 + 右单",
    "intro": "栖木功能沙发是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "栖木功能沙发",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 3.0 米 / 坐深 1.02 米 / 仿皮面料 / 电动功能位",
    "cardTags": [
      "直排沙发",
      "功能沙发",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-04|栖木功能沙发|仿皮面料 / 电动功能位|左单 + 无单 + 右单|2026 示例系列|直排沙发|功能沙发|三人位",
    "detailPath": "/pkg/p1/index?id=DEMO-04",
    "images": [
      "/pkg/p1/assets/products/DEMO-04/cover.jpg",
      "/pkg/p1/assets/products/DEMO-04/side.jpg",
      "/pkg/p1/assets/products/DEMO-04/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-04/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-04/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 3.0 米 / 坐深 1.02 米"
      },
      {
        "label": "材质",
        "value": "仿皮面料 / 电动功能位"
      },
      {
        "label": "组合",
        "value": "左单 + 无单 + 右单"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-04/detail.jpg"
    ]
  },
  {
    "id": "DEMO-05",
    "name": "DEMO-05",
    "displayName": "浅境 U 型沙发",
    "cover": "/pkg/p1/assets/products/DEMO-05/cover.jpg",
    "structureCategory": [
      "U型沙发",
      "四人位",
      "布艺沙发"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 4.1 米 / 坐深 1.05 米",
    "material": "棉麻面料 / 高密度海绵",
    "configuration": "转角 + 单位 + 贵妃位",
    "intro": "浅境 U 型沙发是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "浅境 U 型沙发",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 4.1 米 / 坐深 1.05 米 / 棉麻面料 / 高密度海绵",
    "cardTags": [
      "U型沙发",
      "四人位",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-05|浅境 U 型沙发|棉麻面料 / 高密度海绵|转角 + 单位 + 贵妃位|2026 示例系列|U型沙发|四人位|布艺沙发",
    "detailPath": "/pkg/p1/index?id=DEMO-05",
    "images": [
      "/pkg/p1/assets/products/DEMO-05/cover.jpg",
      "/pkg/p1/assets/products/DEMO-05/side.jpg",
      "/pkg/p1/assets/products/DEMO-05/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-05/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-05/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 4.1 米 / 坐深 1.05 米"
      },
      {
        "label": "材质",
        "value": "棉麻面料 / 高密度海绵"
      },
      {
        "label": "组合",
        "value": "转角 + 单位 + 贵妃位"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-05/detail.jpg"
    ]
  },
  {
    "id": "DEMO-06",
    "name": "DEMO-06",
    "displayName": "白榆单椅组合",
    "cover": "/pkg/p1/assets/products/DEMO-06/cover.jpg",
    "structureCategory": [
      "直排沙发",
      "双人位",
      "布艺沙发"
    ],
    "annualCategory": "2026 示例系列",
    "size": "总长 1.9 米 / 坐深 0.9 米",
    "material": "棉麻面料 / 金属脚",
    "configuration": "双人位 + 脚踏",
    "intro": "白榆单椅组合是一条用于开源演示的示例产品数据，保留了图册、筛选和详情页的完整交互。页面中的尺寸、材质和图片均为占位内容，可按实际业务替换。",
    "alias": "",
    "heroTitle": "白榆单椅组合",
    "heroDescription": "这是一组脱敏后的演示文案，用于展示首页轮播与产品详情的视觉效果。开发者可以替换为真实产品名称、卖点和图片资源。",
    "cardDescription": "总长 1.9 米 / 坐深 0.9 米 / 棉麻面料 / 金属脚",
    "cardTags": [
      "直排沙发",
      "双人位",
      "2026 示例系列"
    ],
    "searchKeywords": "DEMO-06|白榆单椅组合|棉麻面料 / 金属脚|双人位 + 脚踏|2026 示例系列|直排沙发|双人位|布艺沙发",
    "detailPath": "/pkg/p1/index?id=DEMO-06",
    "images": [
      "/pkg/p1/assets/products/DEMO-06/cover.jpg",
      "/pkg/p1/assets/products/DEMO-06/side.jpg",
      "/pkg/p1/assets/products/DEMO-06/detail.jpg"
    ],
    "parameterImages": [
      {
        "title": "尺寸示意",
        "image": "/pkg/p1/assets/products/DEMO-06/diagram.png"
      },
      {
        "title": "结构示意",
        "image": "/pkg/p1/assets/products/DEMO-06/structure.png"
      }
    ],
    "dimensions": [
      {
        "label": "尺寸",
        "value": "总长 1.9 米 / 坐深 0.9 米"
      },
      {
        "label": "材质",
        "value": "棉麻面料 / 金属脚"
      },
      {
        "label": "组合",
        "value": "双人位 + 脚踏"
      }
    ],
    "rawText": "开源演示数据：请替换为你的产品参数。",
    "specTextFile": "",
    "realSceneImages": [
      "/pkg/p1/assets/products/DEMO-06/detail.jpg"
    ]
  }
];

const productMap = {};
products.forEach((item) => {
  productMap[item.id] = item;
});

module.exports = {
  products,
  productMap
};
