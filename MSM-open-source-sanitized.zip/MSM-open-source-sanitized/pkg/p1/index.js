const { productMap } = require('./products');
const { contactInfo } = require('../../data/contact');
const { switchTab } = require('../../utils/actions');

Page({
  data: {
    product: null,
    primaryPhone: contactInfo.phones[0].number
  },

  onLoad(options) {
    const product = productMap[options.id];

    if (!product) {
      wx.showToast({
        title: '未找到该产品',
        icon: 'none'
      });

      setTimeout(() => {
        switchTab('/pages/products/index');
      }, 900);
      return;
    }

    wx.setNavigationBarTitle({
      title: product.displayName
    });

    this.setData({
      product
    });
  },

  previewMedia(event) {
    const { src } = event.currentTarget.dataset;
    const urls = this.getPreviewUrls();

    if (!src || !urls.length) {
      return;
    }

    wx.previewImage({
      current: src,
      urls
    });
  },

  getPreviewUrls() {
    if (!this.data.product) {
      return [];
    }

    return this.data.product.images.concat(
      this.data.product.parameterImages.map((item) => item.image)
    ).concat(
      this.data.product.realSceneImages || []
    );
  }
});
